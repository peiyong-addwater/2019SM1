package com.ezshare.server.model;

public class Server {
	public String hostname = "";
	public int port;
}