package com.ezshare.client;

public class Exchange {
	public String hostname;
	public int port;
	
	public Exchange(String hostName, int port){
		this.hostname = hostName;
		this.port = port;
	}
}
