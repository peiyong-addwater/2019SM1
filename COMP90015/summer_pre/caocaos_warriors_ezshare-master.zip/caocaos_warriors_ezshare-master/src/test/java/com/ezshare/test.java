package com.ezshare;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder value = new StringBuilder();
		value.append("your number is");
		value.append("2");
		value.append("!");
		System.out.println(value);
		
		String s="a";
		String v=s+"w";
		System.out.println(v);
		

	}

}
