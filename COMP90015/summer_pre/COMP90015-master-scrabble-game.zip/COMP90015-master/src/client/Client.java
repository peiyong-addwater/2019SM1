package client;

import client.gui.MainFrame;

public class Client {

	public static void main(String[] args) {
		// Open UI
		MainFrame.getInstance().setVisible(true);
	}
}