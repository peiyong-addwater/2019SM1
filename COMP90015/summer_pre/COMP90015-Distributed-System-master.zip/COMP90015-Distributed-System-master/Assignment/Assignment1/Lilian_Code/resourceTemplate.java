
public class resourceTemplate {

	// check if resource template has incorrect information
	public static boolean invalid;
	
	// check if resource template is not of correct type
	public static boolean typeError;


}
