package org.sw.comm;  

public enum MessageType {
	STRING,BYTES,FILE
}