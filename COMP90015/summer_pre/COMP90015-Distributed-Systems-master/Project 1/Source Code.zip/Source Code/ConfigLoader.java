import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * Load config file data into program
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */

public class ConfigLoader {
	private ArrayList<Room> rooms; // ArrayList of object Room
	private ArrayList<Config> config = new ArrayList<Config>();

	/**
	 * @return the rooms
	 */
	public ArrayList<Room> getRooms() {
		return rooms;
	}

	/**
	 * @param rooms
	 * the rooms to set
	 */
	public void setRooms(ArrayList<Room> rooms) {
		this.rooms = rooms;
	}

	public ConfigLoader() {
		this.rooms = new ArrayList<Room>();
	}

	// read room file
	public void readRoomFile() {
		try {
			// check whether file exists or not
			File file = new File("rooms.dat");
			if (!file.exists())
				return;

			// read file content
			FileInputStream fis = new FileInputStream("rooms.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);

			// store into ArrayList
			ArrayList<Room> room = (ArrayList<Room>) ois.readObject();
			this.rooms = room;

			ois.close();

		} catch (Exception e) {
			System.out.print(e.toString());
		}
	}

	// write room file
	public void writeRoomFile() {
		try {
			FileOutputStream fos = new FileOutputStream("rooms.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(rooms);
			oos.close();
		} catch (IOException e) {
			System.out.println("IOException error");
			e.printStackTrace();
		}
	}

	public ArrayList<Config> loadConfig(String address) {
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(address));

			// Read the line from the file
			String configLine = fileReader.readLine();

			while (configLine != null) {

				// Split the string into substrings delimited by tabs
				String[] configParams = configLine.split("\t");

				// We should have two substrings, one for the IP and one for the
				// port
				if (configParams.length == 4) {
					String serverId = configParams[0];
					String serverAddress = configParams[1];
					int clientPort = Integer.parseInt(configParams[2]);
					int coordinationPort = Integer.parseInt(configParams[3]);
					config.add(new Config(serverId, serverAddress, clientPort, coordinationPort));

					configLine = fileReader.readLine();
				}

			}
			fileReader.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return config;
	}

}
