/**
 * Config
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class Config {
	private String serverId;
	private String serverAddress;
	private int clientPort;
	private int coordinationPort;

	public Config(String serverId, String serverAddress, int clientPort, int coordinationPort) {
		super();
		this.serverId = serverId;
		this.serverAddress = serverAddress;
		this.clientPort = clientPort;
		this.coordinationPort = coordinationPort;
	}

	/**
	 * @param serverId
	 *            the serverId to set
	 */
	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	/**
	 * @param serverAddress
	 *            the serverAddress to set
	 */
	public void setServerAddress(String serverAddress) {
		this.serverAddress = serverAddress;
	}

	/**
	 * @param clientPort
	 *            the clientPort to set
	 */
	public void setClientPort(int clientPort) {
		this.clientPort = clientPort;
	}

	/**
	 * @param coordinationPort
	 *            the coordinationPort to set
	 */
	public void setCoordinationPort(int coordinationPort) {
		this.coordinationPort = coordinationPort;
	}

	public String getServerId() {
		return serverId;
	}

	public int getClientPort() {
		return clientPort;
	}

	public int getCoordinationPort() {
		return coordinationPort;
	}

	public String getServerAddress() {
		return serverAddress;
	}

}
