import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * JSON format message
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class ServerMessages {
	public static JSONObject lockIdRequest(String serverId, String identity) {
		JSONObject lockId = new JSONObject();
		lockId.put("type", "lockidentity");
		lockId.put("serverid", serverId);
		lockId.put("identity", identity);
		return lockId;
	}

	public static JSONObject lockIdReply(String serverId, String identity, String locked) {
		JSONObject lockIdReply = new JSONObject();
		lockIdReply.put("type", "lockidentity");
		lockIdReply.put("serverid", serverId);
		lockIdReply.put("identity", identity);
		lockIdReply.put("locked", locked);
		return lockIdReply;
	}

	public static JSONObject newIdReply(String approved) {
		JSONObject newId = new JSONObject();
		newId.put("type", "newidentity");
		newId.put("approved", approved);
		return newId;
	}

	public static JSONObject releaseIdRequest(String serverId, String identity) {
		JSONObject release = new JSONObject();
		release.put("type", "releaseidentity");
		release.put("serverid", serverId);
		release.put("identity", identity);
		return release;
	}

	public static JSONObject roomchangeBroad(String identity, String former, String roomid) {
		JSONObject changeroom = new JSONObject();
		changeroom.put("type", "roomchange");
		changeroom.put("identity", identity);
		changeroom.put("former", former);
		changeroom.put("roomid", roomid);
		return changeroom;
	}

	public static JSONObject listRequest() {
		JSONObject roomlist = new JSONObject();
		roomlist.put("type", "list");
		return roomlist;
	}

	public static JSONObject listReply(ArrayList<String> roomName) {
		JSONObject roomlist = new JSONObject();
		roomlist.put("type", "roomlist");
		JSONArray rooms = new JSONArray();
		for (int i = 0; i < roomName.size(); i++) {
			rooms.add(i, roomName.get(i));
			System.out.println("add " + roomName.get(i) + "success...\n");
		}
		roomlist.put("rooms", rooms);
		System.out.println("room list size: " + rooms.size() + "\n");
		System.out.println("put room list success...\n");

		return roomlist;
	}

	public static JSONObject whoReply(String roomId) {
		JSONObject wholist = new JSONObject();
		wholist.put("type", "roomcontents");
		wholist.put("roomid", roomId);
		JSONArray identities = new JSONArray();
		// TODO: make sure static ArrayList rooms ???
		for (Room r : Server.rooms) {
			if (r.getName().equals(roomId)) {
				ArrayList<String> guests = r.getGuests();
				for (int i = 0; i < guests.size(); i++) {
					identities.add(i, guests.get(i));
				}
			}
		}
		wholist.put("identities", identities);

		// make sure static ArrayList rooms ???
		for (Room r : Server.rooms) {
			if (r.getName().equals(roomId)) {
				wholist.put("owner", r.getAdmin());
			}
		}

		return wholist;
	}

	public static JSONObject createroomReply(String roomId, String approved) {
		JSONObject roomReply = new JSONObject();
		roomReply.put("type", "createroom");
		roomReply.put("roomid", roomId);
		roomReply.put("approved", approved);
		return roomReply;
	}

	public static JSONObject lockroomIdRequest(String serverid, String roomid) {
		JSONObject lockRoom = new JSONObject();
		lockRoom.put("type", "lockroomid");
		lockRoom.put("serverid", serverid);
		lockRoom.put("roomid", roomid);
		return lockRoom;
	}

	public static JSONObject lockroomIdReply(String serverid, String roomid, String locked) {
		JSONObject lockRoomReply = new JSONObject();
		lockRoomReply.put("type", "lockroomid");
		lockRoomReply.put("serverid", serverid);
		lockRoomReply.put("roomid", roomid);
		lockRoomReply.put("locked", locked);
		return lockRoomReply;
	}

	public static JSONObject releaseroomIdRequest(String serverid, String roomid, String approved) {
		JSONObject releaseRoom = new JSONObject();
		releaseRoom.put("type", "releaseroomid");
		releaseRoom.put("serverid", serverid);
		releaseRoom.put("roomid", roomid);
		releaseRoom.put("approved", approved);
		return releaseRoom;
	}

	public static JSONObject routeReply(String roomid, String host, String port) {
		JSONObject route = new JSONObject();
		route.put("type", "route");
		route.put("roomid", roomid);
		route.put("host", host);
		route.put("port", port);
		return route;
	}

	public static JSONObject serverChangeReply(String approved, String serverid) {
		JSONObject changeserver = new JSONObject();
		changeserver.put("type", "serverchange");
		changeserver.put("approved", approved);
		changeserver.put("serverid", serverid);
		return changeserver;
	}

	public static JSONObject deleteroomReply(String roomid, String approved) {
		JSONObject deleteroom = new JSONObject();
		deleteroom.put("type", "deleteroom");
		deleteroom.put("roomid", roomid);
		deleteroom.put("approved", approved);
		return deleteroom;
	}

	public static JSONObject deleteroomBroad(String serverid, String roomid) {
		JSONObject delete = new JSONObject();
		delete.put("type", "deleteroom");
		delete.put("serverid", serverid);
		delete.put("roomid", roomid);
		return delete;
	}

	public static JSONObject messageReply(String identity, String content) {
		JSONObject message = new JSONObject();
		message.put("type", "message");
		message.put("identity", identity);
		message.put("content", content);
		return message;
	}

	public static JSONObject getQuitRequest() {
		JSONObject quit = new JSONObject();
		quit.put("type", "quit");
		return quit;
	}
}
