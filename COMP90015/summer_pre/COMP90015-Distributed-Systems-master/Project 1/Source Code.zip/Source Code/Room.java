import java.util.ArrayList;

/**
 * Room
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class Room {
	private ArrayList<String> guests = new ArrayList<String>();
	private String admin;
	private String name;
	private String serverId;

	public Room() {

	}

	public Room(String name, String admin, String serverId) {
		this.name = name;
		this.admin = admin;
		this.serverId = serverId;
	}

	public Room(String name, String admin) {
		this.name = name;
		this.admin = admin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	public int getSize() {
		return guests.size();
	}

	public String getAdmin() {
		return admin;
	}

	public void addGuest(String guest) {
		guests.add(guest);
	}

	public void removeGuest(String guest) {
		guests.remove(guest);
	}

	public void clearAdmin() {
		this.admin = "";
	}

	public void changeGuest(String oldGuest, String newGuest) {
		if (admin.equals(oldGuest)) {
			admin = newGuest;
		}
		guests.set(guests.indexOf(oldGuest), newGuest);
	}

	public ArrayList<String> getGuests() {
		return guests;
	}

}
