
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Client.ClientMessages;

/**
 * Server receive thread, used to receive client's request and reply answer
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class ServerReceiveThread implements Runnable {
	private Socket clientSocket;
	private String serverId;
	private BufferedReader in;
	private DataOutputStream out;
	private JSONParser parser = new JSONParser();
	private boolean run = true;
	private Socket server2serverSocket;

	public ServerReceiveThread(Socket socket, String serverId) throws IOException {
		this.clientSocket = socket;
		this.serverId = serverId;
		this.out = new DataOutputStream(socket.getOutputStream());
	}

	@Override
	public void run() {
		try {
			this.in = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream(), "UTF-8"));	
			while (this.run) {	
				String message = this.in.readLine();
				if(message != null){
					JSONObject request = (JSONObject) this.parser.parse(message);
					MessageReceive(this.clientSocket, this.serverId, request);
				}
				else{
					System.out.println("Null message...close socket...\n");
					System.out.println("Send #quit request again...\n");
					JSONObject request = ServerMessages.getQuitRequest();
					MessageReceive(this.clientSocket, this.serverId, request);
					this.clientSocket.close();
					break;
				}						
			}			

		}catch(NullPointerException e){
			
		}
		catch (ParseException e) {

		} 
		catch (IOException e) {

		}
	}

	private synchronized void MessageReceive(Socket socket, String serverId, JSONObject message) throws IOException, ParseException {
		System.out.println("Message analysising...\n");

		JSONObject sendToOtherServer = new JSONObject();
		JSONObject sendToClient = new JSONObject();
		JSONObject sendToAllClient = new JSONObject();
		String type = (String) message.get("type");

		if (type.equals("newidentity")) {
			System.out.println("newidentity analysising...\n");
			String identity = (String) message.get("identity");
			boolean newguest = true;

			if (identity.length() < 3 || identity.length() > 16) {
				System.out.println("Wrong identity length, must more than 2 and less than 17!");
				sendToClient = ServerMessages.newIdReply("false");
				send(sendToClient);
				return;
			}

			// check local server rooms first
			for (Room room : Server.rooms) {
				ArrayList<String> guests = room.getGuests();
				for (String g : guests) {
					if (g.equals(identity)) {
						newguest = false;
						sendToClient = ServerMessages.newIdReply("false");
						send(sendToClient);
						System.out.println("False! send back to client ...\n");
						return;
					}
				}

			}
			System.out.println("Local rooms analysed over...\n");

			System.out.println("Global rooms analysising ...\n");
			// receive each server's reply
			ArrayList<String> lockIdReply = new ArrayList<String>();

			sendToOtherServer = ServerMessages.lockIdRequest(serverId, identity);

			// try to connect with each active server's coordination port
			for (String s : Server.serversId) {
				if (!s.equals(serverId)) {
					JSONObject replyMessage = sendToServer(s, sendToOtherServer);
					if (replyMessage != null) {
						String replyServerId = (String) replyMessage.get("serverid");
						String locked = (String) replyMessage.get("locked");
						System.out.println(
								"lockidentity Reply: serverId: " + replyServerId + " locked: " + locked + "\n");

						lockIdReply.add(locked);
					}
				}
			}
			System.out.println("Global rooms analysed over ...\n");

			// check each item in lockIdReply ArrayList
			for (String l : lockIdReply) {
				if (l.equals("false")) {
					newguest = false;
					sendToClient = ServerMessages.newIdReply("false");
					send(sendToClient);
					// releaseidentity
					sendToOtherServer = ServerMessages.releaseIdRequest(serverId, identity);
					for (String s : Server.serversId) {
						if (!s.equals(serverId)) {
							sendToServer(s, sendToOtherServer);
						}
					}
					return;
				}
			}

			// all rooms checked, return positive reply, add guest to room,
			// broadcast
			if (newguest == true) {
				String roomName = "MainHall-" + serverId;
				Server.guests.add(identity);
				for (Room room : Server.rooms) {
					if (room.getName().equals(roomName)) {
						room.addGuest(identity);
						System.out.println(identity + " moves to " + roomName);
					}
				}
				sendToClient = ServerMessages.newIdReply("true");
				send(sendToClient);

				// release identity
				sendToOtherServer = ServerMessages.releaseIdRequest(serverId, identity);
				for (String s : Server.serversId) {
					if (!s.equals(serverId)) {
						sendToServer(s, sendToOtherServer);
					}
				}

				// broadcast roomchange
				sendToAllClient = ServerMessages.roomchangeBroad(identity, "", roomName);
				for (Socket so : Server.sockets) {
					DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
					clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
					clientBroad.flush();
				}
				return;
			}
		}

		if (type.equals("list")) {
			System.out.println("list analysising...\n");
			System.out.println("room list analysising ...\n");
			// receive each server's reply
			ArrayList<String> roomName = new ArrayList<String>();

			sendToOtherServer = ServerMessages.listRequest();

			// try to connect with each active server's coordination port
			for (String s : Server.serversId) {
				JSONObject replyMessage = sendToServer(s, sendToOtherServer);
				if (replyMessage != null) {
					System.out.println("Analysising array ...\n");
					System.out.println((String) replyMessage.get("type"));
					JSONArray array = (JSONArray) replyMessage.get("rooms");

					for (int i = 0; i < array.size(); i++) {
						String roomname = (String) array.get(i);
						System.out.println(roomname);
						roomName.add(roomname);
					}
				}
			}
			sendToClient = ServerMessages.listReply(roomName);
			send(sendToClient);
			System.out.println("room list delivered ...\n");
			return;

		}
		if (type.equals("who")) {
			System.out.println("who analysising...\n");
			int clientId = Server.sockets.indexOf(clientSocket);
			String clientName = Server.guests.get(clientId);
			for (Room room : Server.rooms) {
				String roomId = room.getName();
				ArrayList<String> guests = room.getGuests();
				for (String guest : guests) {
					if (guest.equals(clientName)) {
						sendToClient = ServerMessages.whoReply(roomId);
						send(sendToClient);
						return;
					}
				}
			}
		}
		if (type.equals("createroom")) {
			System.out.println("createroom analysising...\n");
			String roomid = (String) message.get("roomid");
			// client message need for create room
			int clientId = Server.sockets.indexOf(clientSocket);
			String clientName = Server.guests.get(clientId);

			boolean newroomid = true;
			// check roomid length
			if (roomid.length() < 3 || roomid.length() > 16) {
				System.out.println("Wrong roomid length, must more than 2 and less than 17!\n");
				sendToClient = ServerMessages.createroomReply(roomid, "false");
				send(sendToClient);
				return;
			}
			// check client is admin?
			for(Room room:Server.rooms){
				if(room.getAdmin().equals(clientName)){
					System.out.println("Client is admin, can not create new room...\n");
					sendToClient = ServerMessages.createroomReply(roomid, "false");
					send(sendToClient);
					return;
				}
			}

			// check local server rooms first
			for (Room room : Server.rooms) {
				String roomName = room.getName();
				if (roomName.equals(roomid)) {
					sendToClient = ServerMessages.createroomReply(roomid, "false");
					send(sendToClient);
					return;
				}
			}
			System.out.println("Local rooms analysed over...\n");

			// check global rooms
			System.out.println("Global rooms analysising ...\n");
			ArrayList<String> lockRoomReply = new ArrayList<String>();
			sendToOtherServer = ServerMessages.lockroomIdRequest(serverId, roomid);
			// try to connect with each active server's coordination port
			for (String s : Server.serversId) {
				if (!s.equals(serverId)) {
					JSONObject replyMessage = sendToServer(s, sendToOtherServer);
					if (replyMessage != null) {
						String replyServerId = (String) replyMessage.get("serverid");
						String locked = (String) replyMessage.get("locked");
						System.out.println("Server-" + replyServerId + " Reply: " + locked);
						lockRoomReply.add(locked);
					}
				}
			}
			System.out.println("Global rooms analysed over ...\n");

			// check each item in lockIdReply ArrayList
			for (String l : lockRoomReply) {
				if (l.equals("false")) {
					newroomid = false;
					sendToClient = ServerMessages.createroomReply(roomid, "false");
					send(sendToClient);
					// releaseidentity
					sendToOtherServer = ServerMessages.releaseroomIdRequest(serverId, roomid, "false");
					for (String s : Server.serversId) {
						if (!s.equals(serverId)) {
							sendToServer(s, sendToOtherServer);
						}
					}
					return;
				}
			}

			// all rooms checked, return positive reply, add guest to room,
			// broadcast
			if (newroomid == true) {
				// inform client create room approved
				sendToClient = ServerMessages.createroomReply(roomid, "true");
				send(sendToClient);
				
				// find former room id
				String formerRoom = "";
				for (Room room : Server.rooms) {
					String roomName = room.getName();
					ArrayList<String> guest = room.getGuests();
					if(guest.contains(clientName)){
						formerRoom = roomName;
						// remove client guest Id
						room.removeGuest(clientName);
						break;
					}
				}
				// create new room and set client as Admin
				Room newRoom = new Room(roomid, clientName);
				newRoom.addGuest(clientName);
				Server.rooms.add(newRoom);

				// release identity
				sendToOtherServer = ServerMessages.releaseroomIdRequest(serverId, roomid, "true");
				for (String s : Server.serversId) {
					if (!s.equals(serverId)) {
						sendToServer(s, sendToOtherServer);
					}
				}
				
				// ==== broadcast room change ====
				sendToAllClient = ServerMessages.roomchangeBroad(clientName, formerRoom, roomid);
				// 1. inform request client
				send(sendToAllClient);
				// 2. inform formerroom's guests
				for (Room r : Server.rooms) {
					String roomName = r.getName();
					if (roomName.equals(formerRoom)) {
						ArrayList<String> guest = r.getGuests();
						for (String g : guest) {
							// get guest index in static Server.guests list
							int guestIndex = Server.guests.indexOf(g);
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();
						}
					}
				}
				return;
			}
		}
		if (type.equals("join")) {
			System.out.println("join analysising...\n");
			String roomid = (String) message.get("roomid");
			String matchServerId = "";
			String mathcServerAddress = "";
			String matchClientPort = "";
			int matchCoordPort = 0;
			// client message need for create room
			int clientIndex = Server.sockets.indexOf(clientSocket);
			String clientName = Server.guests.get(clientIndex);
			String currentRoomName = ""; // room name that client current in
			// copy static room information
			ArrayList<Room> tempRoom = new ArrayList<Room>();
			for (Room r : Server.rooms)
				tempRoom.add(r);
			
			// 1. find current roomid & check client owning a chat room?
			for (Room room : tempRoom) {
				String admin = room.getAdmin();
				if (admin.equals(clientName)) {
					currentRoomName = room.getName();
					// own a room, return negative reply
					sendToClient = ServerMessages.roomchangeBroad(clientName, currentRoomName, currentRoomName);
					send(sendToClient);
					return;
				}
				// not admin, check in which roomid
				ArrayList<String> guest = room.getGuests();
				for (String g : guest) {
					if (g.equals(clientName)) {
						currentRoomName = room.getName();
					}
				}
			}

			// 2. check roomid exit?
			sendToOtherServer = ServerMessages.lockroomIdRequest(serverId, roomid);
			JSONObject sendToOtherServer2 = ServerMessages.releaseroomIdRequest(serverId, roomid, "true");
			boolean match = false;
			// try to connect with each active server's coordination port
			// include current server
			for (String s : Server.serversId) {
				JSONObject replyMessage = sendToServer(s, sendToOtherServer); // lockId
				sendToServer(s, sendToOtherServer2); // releaseId
				if (replyMessage != null) {
					String replyServerId = (String) replyMessage.get("serverid");
					String locked = (String) replyMessage.get("locked");
					// find match room id, save corresponding server information
					if (locked.equals("false")) {
						match = true;
						matchServerId = replyServerId;
						int matchServerIndex = Server.serversId.indexOf(matchServerId);
						mathcServerAddress = Server.serversAddress.get(matchServerIndex);
						matchClientPort = Server.clientsPort.get(matchServerIndex).toString();
						matchCoordPort = Server.coordsPort.get(matchServerIndex);
						break;
					}
				}
			}
			// no match, return negative reply
			if (match == false) {
				System.out.println("Room id does not exit in all system!\n");
				sendToClient = ServerMessages.roomchangeBroad(clientName, currentRoomName, currentRoomName);
				send(sendToClient);
				return;
			}

			// ====== room exit, check local or global? ======
			// 1. check room in local (same server)?
			if (matchServerId.equals(this.serverId)) {
				// same room name?
				if (currentRoomName.equals(roomid)) {
					sendToClient = ServerMessages.roomchangeBroad(clientName, currentRoomName, currentRoomName);
					send(sendToClient);
					return;
				}
				// move to new room, delete old info, broadcast
				else {
					// 1.1 delete from current room + broadcast
					sendToAllClient = ServerMessages.roomchangeBroad(clientName, currentRoomName, roomid);
					send(sendToAllClient);
					for(int i =0; i<tempRoom.size(); i++){
						if (Server.rooms.get(i).getName().equals(currentRoomName)) {
							Server.rooms.get(i).removeGuest(clientName);
							ArrayList<String> guest = Server.rooms.get(i).getGuests();
							for(int j=0;j<guest.size(); j++){
								// get guest index in static Server.guests list
								int guestIndex = Server.guests.indexOf(guest.get(j));
								// find corresponding socket
								Socket so = Server.sockets.get(guestIndex);
								DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
							}
						}
					}
					// 1.2 add to new room + broadcast (include request client)
					for(int i=0; i<tempRoom.size(); i++){
						if (Server.rooms.get(i).getName().equals(roomid)) {
							Server.rooms.get(i).addGuest(clientName);
							ArrayList<String> guest = Server.rooms.get(i).getGuests();
							for (String g : guest) {
								// get guest index in static Server.guests list
								int guestIndex = Server.guests.indexOf(g);
								// find corresponding socket
								Socket so = Server.sockets.get(guestIndex);
								DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
							}
						}
					}
				}
			}
			// 2. find room position in other servers
			else {
				// 2.1 remove from former room + broadcast to former room
				sendToAllClient = ServerMessages.roomchangeBroad(clientName, currentRoomName, roomid);
				for(int i=0; i<tempRoom.size(); i++){			
					if (Server.rooms.get(i).getName().equals(currentRoomName)) {
						Server.rooms.get(i).removeGuest(clientName);
						ArrayList<String> guest = Server.rooms.get(i).getGuests();
						for(int j=0; j<guest.size(); j++){
							// get guest index in static Server.guests list
							int guestIndex = Server.guests.indexOf(guest.get(j));
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();
						}
					}
				}
				// 2.2 reply 'route' message
				sendToClient = ServerMessages.routeReply(roomid, mathcServerAddress, matchClientPort);
				send(sendToClient);
				
				Server.guests.remove(clientName);
				Server.sockets.remove(clientIndex);
			}
			return;

		}
		if (type.equals("movejoin")) {
			System.out.println("movejoin analysising...\n");
			String former = (String) message.get("former");
			String roomid = (String) message.get("roomid");
			String identity = (String) message.get("identity");
			String mainHall = "MainHall-" + serverId;
			boolean mainRoom = true; // move to mainHall
			// copy static room information
			ArrayList<Room> tempRoom = new ArrayList<Room>();
			for(Room r:Server.rooms)
				tempRoom.add(r);
			
			// must reply 'serverChange' before broadcast
			sendToClient = ServerMessages.serverChangeReply("true", serverId);
			sendToAllClient = ServerMessages.roomchangeBroad(identity, former, roomid);		
			for(int i=0; i<tempRoom.size(); i++){
				// add client in room + broadcast
				if (tempRoom.get(i).getName().equals(roomid)) {
					Server.rooms.get(i).addGuest(identity);
					Server.guests.add(identity);
					send(sendToClient);
					mainRoom = false; // done't need to move to mainHall
					// broadcast
					ArrayList<String> tempGuest = new ArrayList<String>();
					for(String s:Server.rooms.get(i).getGuests())
						tempGuest.add(s);
					
					for(int j=0; j<tempGuest.size(); j++){
						// get guest index in static Server.guests list
						int guestIndex = Server.guests.indexOf(tempGuest.get(j));
						// find corresponding socket
						Socket so = Server.sockets.get(guestIndex);
						DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
						clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
						clientBroad.flush();
					}
				}
			}
			// Room deleted, put client in MainHall + broadcast
			if (mainRoom == true) {			
				for(int i=0; i<tempRoom.size(); i++){
					if (Server.rooms.get(i).getName().equals(mainHall)) {
						Server.rooms.get(i).addGuest(identity);
						Server.guests.add(identity);
						send(sendToClient);
						// broadcast
						ArrayList<String> tempGuest = new ArrayList<String>();
						for(String s:Server.rooms.get(i).getGuests())
							tempGuest.add(s);
						for(int j=0; j<tempGuest.size(); j++){
							// get guest index in static Server.guests list
							int guestIndex = Server.guests.indexOf(tempGuest.get(j));
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();
						}
					}
				}
			}
			System.out.println("movejoin end...\n");
			return;

		}
		if (type.equals("deleteroom")) {
			System.out.println("deleteroom analysising...\n");
			String roomid = (String) message.get("roomid");
			// client message need for create room
			int clientIndex = Server.sockets.indexOf(clientSocket);
			String clientName = Server.guests.get(clientIndex);
			String mainHallName = "MainHall-"+serverId;
			// copy static room information
			ArrayList<Room> tempRoom = new ArrayList<Room>();
			for (Room r : Server.rooms)
				tempRoom.add(r);

			// 1. find current roomid & check client owning a chat room?
			for(int i=0; i<tempRoom.size(); i++){
				if (Server.rooms.get(i).getName().equals(roomid)) {
					// not admin, refuse request
					if (!Server.rooms.get(i).getAdmin().equals(clientName)) {
						System.out.println("not admin, can not delete room ...\n");
						sendToClient = ServerMessages.deleteroomReply(roomid, "false");
						send(sendToClient);
						return;
					} else {// is admin move to MainHall
						ArrayList<String> mainguest = new ArrayList<String>();
						for(String s:Server.rooms.get(0).getGuests())
							mainguest.add(s);
						
						ArrayList<String> oldguest = new ArrayList<String>();
						for(String s:Server.rooms.get(i).getGuests())
							oldguest.add(s);
							
						for (String g : oldguest) {
							Server.rooms.get(0).addGuest(g);
						}
						// delete room
						Server.rooms.remove(i);
						
						// reply request client
						sendToClient = ServerMessages.deleteroomReply(roomid, "true");
						send(sendToClient);
						
						// broadcast 'room change'
						// 1. to guest in delete room
						for (String old : oldguest) {
							int guestIndex = Server.guests.indexOf(old);
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							sendToAllClient = ServerMessages.roomchangeBroad(old, roomid, mainHallName);
							// get guest index in static Server.guests list
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();

						}
						
						// 2. to mainhall guest
						ArrayList<String> newguest = Server.rooms.get(0).getGuests();
						for (String g : mainguest) {
							int guestIndex = Server.guests.indexOf(g);
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							for (String gu : oldguest) {
								sendToAllClient = ServerMessages.roomchangeBroad(gu, roomid, mainHallName);
								// get guest index in static Server.guests list
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
							}
						}			
						return;
					}
				}

			}
			// all room checked, roomid not exit
			System.out.println("room id is not exist local...\n");
			sendToClient = ServerMessages.deleteroomReply(roomid, "false");
			send(sendToClient);	
			return;		

		}
		if (type.equals("message")) {
			System.out.println("message analysising...\n");
			String content = (String) message.get("content");
			// client message need for create room
			int clientIndex = Server.sockets.indexOf(clientSocket);
			String clientName = Server.guests.get(clientIndex);
			
			// find room
			sendToAllClient = ServerMessages.messageReply(clientName, content);			
			for(Room room:Server.rooms){
				ArrayList<String> guest = room.getGuests();
				if(guest.contains(clientName)){
					for(String g:guest){
						if(!g.equals(clientName)){
							int guestIndex = Server.guests.indexOf(g);
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							// get guest index in static Server.guests list
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();
						}
					}
					return;
				}			
			}			
		}
		if (type.equals("quit")) {
			// client message need for create room
			int clientIndex = Server.sockets.indexOf(clientSocket);
			// check if client still exit in guest list?
			// 1. no: already quit, return nothing
			if(clientIndex == -1){
				return;
			}
			
			// 2. yes: was force quit, still in list	
			String clientName = Server.guests.get(clientIndex);
			String currentRoom = "";
			String mainHallName = "MainHall-"+serverId;
			// copy mainhall guest
			ArrayList<String> mainHallguest = new ArrayList<String>();
			for (String s : Server.rooms.get(0).getGuests())
				mainHallguest.add(s);
			
			// copy static room information
			ArrayList<Room> tempRoom = new ArrayList<Room>();
			for (Room r:Server.rooms)
				tempRoom.add(r);
			
			for(int i = 0; i<tempRoom.size(); i++){			
				ArrayList<String> guest = new ArrayList<String>();
				for(String s:Server.rooms.get(i).getGuests())
					guest.add(s);
						
				currentRoom = Server.rooms.get(i).getName();
				
				if( Server.rooms.get(i).getGuests().contains(clientName)){
					// check admin? -- No --> delete + broadcast
					if(!Server.rooms.get(i).getAdmin().equals(clientName)){
						Server.rooms.get(i).removeGuest(clientName);
						sendToAllClient = ServerMessages.roomchangeBroad(clientName, currentRoom, "");
						ArrayList<String> newguest = Server.rooms.get(i).getGuests();
						for(String g:newguest){
							int guestIndex = Server.guests.indexOf(g);
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							// get guest index in static Server.guests list
							clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
							clientBroad.flush();
						}
						// reply request client
						sendToClient = ServerMessages.roomchangeBroad(clientName, currentRoom, "");
						send(sendToClient);
						
					}
					else{// check admin? -- Yes --> move + delete + broadcast					
						// move guests
						for(int k = 0; k<guest.size(); k++){			
							if(!guest.get(k).equals(clientName)){
								Server.rooms.get(0).addGuest(Server.rooms.get(i).getGuests().get(k));
							}
						}
						// delete room
						Server.rooms.remove(Server.rooms.get(i));
						
						// reply request client
						sendToClient = ServerMessages.deleteroomReply(currentRoom, "true");
						send(sendToClient);
						// reply request client
						sendToClient = ServerMessages.roomchangeBroad(clientName, currentRoom, "");
						send(sendToClient);
						
						// broadcast 'room change'
						// 1. to deleted room guest
						for(int l = 0; l<guest.size(); l++){
							if(!guest.get(l).equals(clientName)){
								int guestIndex = Server.guests.indexOf(guest.get(l));
								// find corresponding socket
								Socket so = Server.sockets.get(guestIndex);
								DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
								
								sendToAllClient = ServerMessages.roomchangeBroad(clientName, currentRoom, "");
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
								sendToAllClient = ServerMessages.roomchangeBroad(guest.get(l), currentRoom, mainHallName);
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
							}
						}
						
						
						// 2. to mainhall room guest
						for (int m = 0; m < mainHallguest.size(); m++) {
							// for (String g : mainHallguest) {
							// if (!guest.contains((mainHallguest.get(m)))) {
							int guestIndex = Server.guests.indexOf(mainHallguest.get(m));
							// find corresponding socket
							Socket so = Server.sockets.get(guestIndex);
							DataOutputStream clientBroad = new DataOutputStream(so.getOutputStream());
							for (int g = 0; g < guest.size(); g++) {
								// for (String gu : guest) {
								if (guest.get(g).equals(clientName)) {
									sendToAllClient = ServerMessages.roomchangeBroad(guest.get(g), currentRoom, "");
								} else {
									sendToAllClient = ServerMessages.roomchangeBroad(guest.get(g), currentRoom,
											mainHallName);
								}
								clientBroad.write((sendToAllClient.toJSONString() + "\n").getBytes("UTF-8"));
								clientBroad.flush();
							}
						}
					}
				}

			}
			Server.guests.remove(clientIndex);
			Server.sockets.remove(clientIndex);
			return;
		}
	}

	private void send(JSONObject obj) throws IOException {
		this.out.write((obj.toJSONString() + "\n").getBytes("UTF-8"));
		this.out.flush();
	}

	private JSONObject sendToServer(String s, JSONObject sendToOtherServer) throws IOException, ParseException {
		System.out.println("Server-" + s + " start...\n");
		String type = (String) sendToOtherServer.get("type");
		String address = Server.serversAddress.get(Server.serversId.indexOf(s));
		int coordPort = Server.coordsPort.get(Server.serversId.indexOf(s));
		JSONObject replyMessage = null;
		try {
			server2serverSocket = new Socket(address, coordPort);
		} catch (Exception e) {
			// inactive server, return null, wait for next serverId
			System.out.println("Server-" + s + " is inactive and jump to next server...\n");
			return null;
		}
		// connected to active server, send request
		DataOutputStream serverRequest = new DataOutputStream(server2serverSocket.getOutputStream());
		serverRequest.write((sendToOtherServer.toJSONString() + "\n").getBytes("UTF-8"));
		serverRequest.flush();
		if (type.equals("releaseidentity") || type.equals("releaseroomid")) {
			replyMessage = null;
		} else {
			// receive reply from server
			BufferedReader serverReply = new BufferedReader(
					new InputStreamReader(server2serverSocket.getInputStream(), "UTF-8"));
			JSONParser serverparser = new JSONParser();
			replyMessage = (JSONObject) serverparser.parse(serverReply.readLine());
		}
		
		return replyMessage;
	}

}
