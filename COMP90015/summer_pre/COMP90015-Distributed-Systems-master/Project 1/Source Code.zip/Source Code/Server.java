import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.text.ParseException;
import java.util.ArrayList;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

/**
 * Server
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class Server {

	public static ArrayList<Thread> clients = new ArrayList<Thread>();
	public static ArrayList<Socket> sockets = new ArrayList<Socket>();
	public static ArrayList<String> guests = new ArrayList<String>();
	public static ArrayList<Room> rooms = new ArrayList<Room>();

	public static ArrayList<ServerSocket> servers = new ArrayList<ServerSocket>();
	// all servers config informatin from file
	public static ArrayList<Config> serverConfig = new ArrayList<Config>();
	// availabe servers' config information for program
	public static ArrayList<Config> serverConfigUsed = new ArrayList<Config>();
	public static ArrayList<String> serversId = new ArrayList<String>();
	public static ArrayList<String> serversAddress = new ArrayList<String>();
	public static ArrayList<Integer> clientsPort = new ArrayList<Integer>();
	public static ArrayList<Integer> coordsPort = new ArrayList<Integer>();
	public static ArrayList<String> lockId = new ArrayList<String>();
	public static ArrayList<String> lockIdServer = new ArrayList<String>();
	public static ArrayList<String> lockRoomId = new ArrayList<String>();
	public static ArrayList<String> lockRoomIdServer = new ArrayList<String>();

	public static void main(String[] args) throws IOException, ParseException, CmdLineException {
		ServerSocket clientSocket = null; // accept clients' sockets
		ServerSocket serverSocket = null; // accept servers' sockets
		String serverId = null;
		String serverConf = null;
		ServerCommandLineValues values = new ServerCommandLineValues();
		CmdLineParser parser = new CmdLineParser(values);

		try {
			parser.parseArgument(args);
			serverId = values.getServerId();
			serverConf = values.getServerConf();
			ConfigLoader configLoader = new ConfigLoader();
			serverConfig = configLoader.loadConfig(serverConf);

			// Check serveraddress + port used or not?
			if (checkServerEmpty(serverId) == false) {
				System.out.println("Server Id occupied, please try another one!");
				System.exit(1);
			}

			for (Config configs : serverConfig) {
				String sId = configs.getServerId();
				String sAddress = configs.getServerAddress();
				int clientPort = configs.getClientPort();
				int coordPort = configs.getCoordinationPort();
				// save all server information from config to local file
				serversId.add(sId);
				serversAddress.add(sAddress);
				clientsPort.add(clientPort);
				coordsPort.add(coordPort);

				// only active specific server socket
				if (configs.getServerId().equals(serverId)) {
					// create MainHall
					rooms.add(new Room("MainHall-" + sId, ""));

					clientSocket = new ServerSocket(clientPort, 100, InetAddress.getByName(sAddress));
					System.out.println("Server " + serverId + " created.\n");
					serverSocket = new ServerSocket(coordPort, 100, InetAddress.getByName(sAddress));

				}
			}

			System.out.println("Server is listening...\n");

			ServerSendThread serverSendThread = new ServerSendThread(serverSocket, serverId);
			Thread sendThread = new Thread(serverSendThread);
			sendThread.start();

			while (true) {
				Socket socketClient = clientSocket.accept();
				sockets.add(socketClient);

				ServerReceiveThread serverReceiveThread = new ServerReceiveThread(socketClient, serverId);
				Thread receiveThread = new Thread(serverReceiveThread);
				receiveThread.start();
				System.out.println("Server receiveThread start!\n");
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (clientSocket != null)
				clientSocket.close();
		}

		System.out.println("Server sendThread start!\n");
	}

	private static boolean checkServerEmpty(String serverId) {
		boolean result = true;
		if (serverConfigUsed.size() == 0)
			return true;

		for (Config c : serverConfigUsed) {
			if (c.getServerId().equals(serverId))
				return false;
		}
		return result;
	}

}
