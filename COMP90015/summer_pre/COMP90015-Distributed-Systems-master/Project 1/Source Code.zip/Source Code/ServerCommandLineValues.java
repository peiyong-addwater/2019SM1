import org.kohsuke.args4j.Option;

/**
 * Format jar input variables
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class ServerCommandLineValues {
	// java -jar server.jar -n serverid -l servers_conf

	@Option(required = true, name = "-n", aliases = { "--serverId" }, usage = "server Id name")
	private String serverId;
	@Option(required = true, name = "-l", aliases = { "--ServerConf" }, usage = "configuration path")
	private String serverConf;

	/**
	 * @return the serverId
	 */
	public String getServerId() {
		return this.serverId;
	}

	/**
	 * @return the serverConf
	 */
	public String getServerConf() {
		return this.serverConf;
	}

}
