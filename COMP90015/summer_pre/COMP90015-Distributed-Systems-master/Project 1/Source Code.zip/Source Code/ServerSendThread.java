import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Server send thread, used to accept server's request and reply answer
 * 
 * @author Hongyao Wei
 * @Student ID: 741027
 *
 */
public class ServerSendThread implements Runnable {
	private Socket socket;
	private DataOutputStream out;
	private BufferedReader in;
	private String serverId;
	private JSONParser parser = new JSONParser();
	private boolean run = true;
	private ServerSocket serverSocket = null;

	public ServerSendThread(ServerSocket serverSocket, String serverId) throws IOException {
		this.serverSocket = serverSocket;
		this.serverId = serverId;
	}

	@Override
	public void run() {
		try {
			while (true) {
				// Server waits for a new connection
				Socket socketServer = serverSocket.accept();
				System.out.println("Server thread connected...\n");
				this.in = new BufferedReader(new InputStreamReader(socketServer.getInputStream(), "UTF-8"));
				this.out = new DataOutputStream(socketServer.getOutputStream());
				System.out.println("ServerSendThread class start!\n");
				JSONObject message = (JSONObject) this.parser.parse(this.in.readLine());
				MessageReceive(socketServer, this.serverId, message);
			}
		} catch (ParseException e) {
			// System.out.println("Message Error: " + e.getMessage());
			// System.exit(1);
		} catch (IOException e) {
			// System.out.println("Communication Error: " + e.getMessage());
			// System.exit(1);
		}
	}

	private void MessageReceive(Socket socket, String serverId, JSONObject message) throws IOException, ParseException {
		String type = (String) message.get("type");
		JSONObject reply = new JSONObject();

		if (type.equals("lockidentity")) {
			// add id into lockId list + check same id?
			String lockServer = (String) message.get("serverid");
			String identity = (String) message.get("identity");

			String locked = "true";
			// check lockId list
			for (String id : Server.lockId) {
				if (id.equals(identity)) {
					locked = "false";
					reply = ServerMessages.lockIdReply(serverId, identity, locked);
					this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
					this.out.flush();
					return;
				}
			}
			// not locked, add into list
			Server.lockId.add(identity);
			Server.lockIdServer.add(lockServer);

			// check each guest name in each room
			for (Room room : Server.rooms) {
				ArrayList<String> guests = room.getGuests();
				for (String g : guests) {
					if (g.equals(identity)) {
						locked = "false";
						reply = ServerMessages.lockIdReply(serverId, identity, locked);
						this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
						this.out.flush();
						return;
					}
				}
			}
			// no match, reply positive answer
			reply = ServerMessages.lockIdReply(serverId, identity, locked);
			this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
			this.out.flush();
			return;
		}
		if (type.equals("releaseidentity")) {
			// remove id from lockId list
			String lockServer = (String) message.get("serverid");
			String identity = (String) message.get("identity");

			// System.out.println(lockServer + " + " + identity);
			// System.out.println("Server.lockId size: "+ Server.lockId.size());

			if (Server.lockId.contains(identity)) {
				int index = Server.lockId.indexOf(identity);
				if (Server.lockIdServer.get(index).equals(lockServer)) {
					Server.lockId.remove(identity);
					Server.lockIdServer.remove(lockServer);
					// System.out.println(lockServer + " + " + identity + "
					// removed\n");
					// System.out.println("Server.lockId size: "+
					// Server.lockId.size());
				}
			}

			return;
		}
		if (type.equals("list")) {
			ArrayList<String> roomName = new ArrayList<String>();
			for (Room room : Server.rooms) {
				// System.out.println("Test -- "+room.getName());
				roomName.add(room.getName());
				// System.out.println("Add roomName list success\n");
			}
			reply = ServerMessages.listReply(roomName);
			this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
			this.out.flush();
			return;
		}
		if (type.equals("lockroomid")) {
			// add roomid into lockRoomId list + check same id?
			String roomid = (String) message.get("roomid");
			String serverid = (String) message.get("serverid");

			String locked = "true";
			// check lockId list
			for (String id : Server.lockRoomId) {
				if (id.equals(roomid)) {
					locked = "false";
					reply = ServerMessages.lockroomIdReply(serverId, roomid, locked);
					this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
					this.out.flush();
					return;
				}
			}
			// not locked, add into list
			Server.lockRoomId.add(roomid);
			Server.lockRoomIdServer.add(serverid);

			// search each room
			for (Room room : Server.rooms) {
				String roomName = room.getName();
				if (roomName.equals(roomid)) {
					locked = "false";
					// roomid occupied, reply negative result
					reply = ServerMessages.lockroomIdReply(serverId, roomid, locked);
					this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
					this.out.flush();
					return;
				}
			}

			// roomid available, reply positive result
			reply = ServerMessages.lockroomIdReply(serverId, roomid, locked);
			this.out.write((reply.toJSONString() + "\n").getBytes("UTF-8"));
			this.out.flush();
			return;

		}
		if (type.equals("releaseroomid")) {
			// remove roomid from lockRoomId list
			String lockServer = (String) message.get("serverid");
			String roomid = (String) message.get("roomid");
			String approved = (String) message.get("approved");

			if (Server.lockRoomId.contains(roomid)) {
				int index = Server.lockRoomId.indexOf(roomid);
				if (Server.lockRoomIdServer.get(index).equals(lockServer)) {
					Server.lockRoomId.remove(roomid);
					Server.lockRoomIdServer.remove(lockServer);
				}
			}
			return;
		}
	}

}
