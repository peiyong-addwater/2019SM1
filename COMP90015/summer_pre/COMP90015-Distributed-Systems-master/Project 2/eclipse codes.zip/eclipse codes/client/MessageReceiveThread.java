package chatSystem.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class MessageReceiveThread implements Runnable {

	private SSLSocket sslsocket;
	private State state;
	private boolean debug;

	private BufferedReader in;

	private JSONParser parser = new JSONParser();

	private boolean run = true;
	
	private MessageSendThread messageSendThread;
	private JTextArea textAreaDisplayMsg;
	private DefaultListModel<String> listModel;
	private JComboBox<String> cboRoomList;
	private JTextField textFieldHostName;
	private JTextField textFieldPort;
	private JButton btnLogin;

	public MessageReceiveThread(SSLSocket sslsocket, State state, MessageSendThread messageSendThread, 
			boolean debug, JTextArea textAreaDisplayMsg, DefaultListModel<String> listMode, JComboBox<String> cboRoomList, 
			JButton btnLogin, JTextField textFieldHostName, JTextField textFieldPort) throws IOException {
		this.sslsocket = sslsocket;
		this.state = state;
		this.messageSendThread = messageSendThread;
		this.debug = debug;
		this.textAreaDisplayMsg = textAreaDisplayMsg;
		this.listModel = listMode;
		this.cboRoomList = cboRoomList;
		this.btnLogin = btnLogin;
		this.textFieldHostName = textFieldHostName;
		this.textFieldPort = textFieldPort;
	}

	@Override
	public void run() {

		try {
			this.in = new BufferedReader(new InputStreamReader(
					sslsocket.getInputStream(), "UTF-8"));
			JSONObject message;
			while (run) {
				message = (JSONObject) parser.parse(in.readLine());
				if (debug) {
					textAreaDisplayMsg.append("Receiving: " + message.toJSONString()+"\r\n");
					textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
					textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
				}
				MessageReceive(sslsocket, message);
			}
			System.exit(0);
			in.close();
			sslsocket.close();
		} catch (ParseException e) {
			textAreaDisplayMsg.append("Message Error: " + e.getMessage()+"\r\n");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			System.exit(1);
		} catch (IOException e) {
			textAreaDisplayMsg.append("Communication Error: " + e.getMessage()+"\r\n");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			System.exit(1);
		}

	}

	public void MessageReceive(Socket socket, JSONObject message)
			throws IOException, ParseException {
		String type = (String) message.get("type");
		
		// server reply of #login
		if (type.equals("login")) {
			boolean approved = Boolean.parseBoolean((String) message.get("approved"));
			if(!approved){
				JOptionPane.showMessageDialog(null,"Login Info Error!", "Login Error",
						JOptionPane.ERROR_MESSAGE);
				socket.close();
				System.exit(1);
			}
			
		}
		// server reply of #newidentity
		if (type.equals("newidentity")) {
			boolean approved = Boolean.parseBoolean((String) message.get("approved"));
			
			// terminate program if failed
			if (!approved) {
				JOptionPane.showMessageDialog(null,state.getIdentity() + " already in use.!", "Identity Error",
						JOptionPane.ERROR_MESSAGE);
				socket.close();
				System.exit(1);
			}
			
			if(approved){
				btnLogin.setEnabled(false);
				return;
			}
			
		}
		
		// server reply of #list
		if (type.equals("roomlist")) {
			JSONArray array = (JSONArray) message.get("rooms");
			// print all the rooms
			cboRoomList.removeAllItems();
			for (int i = 0; i < array.size(); i++) {
				cboRoomList.addItem((String) array.get(i));
			}
			return;
		}

		// server sends roomchange
		if (type.equals("roomchange")) {

			// identify whether the user has quit!
			if (message.get("roomid").equals("")) {
				// quit initiated by the current client
				if (message.get("identity").equals(state.getIdentity())) {
					textAreaDisplayMsg.append(message.get("identity") + " has quit!\r\n");
					textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
					in.close();
					System.exit(1);
				} else {
					textAreaDisplayMsg.append(message.get("identity") + " has quit!\r\n");
					textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
					textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
				}
			// identify whether the client is new or not
			} else if (message.get("former").equals("")) {
				// change state if it's the current client
				if (message.get("identity").equals(state.getIdentity())) {
					state.setRoomId((String) message.get("roomid"));
				}
				textAreaDisplayMsg.append(message.get("identity") + " moves to "
						+ (String) message.get("roomid")+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			// identify whether roomchange actually happens
			} else if (message.get("former").equals(message.get("roomid"))) {
				textAreaDisplayMsg.append("room unchanged\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			// print the normal roomchange message
			else {
				// change state if it's the current client
				if (message.get("identity").equals(state.getIdentity())) {
					state.setRoomId((String) message.get("roomid"));
				}
				
				textAreaDisplayMsg.append(message.get("identity") + " moves from " + message.get("former") + " to "
						+ message.get("roomid")+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			return;
		}
		
		// server reply of #who
		if (type.equals("roomcontents")) {
			JSONArray array = (JSONArray) message.get("identities");
			listModel.removeAllElements();
			for (int i = 0; i < array.size(); i++) {
				if (message.get("owner").equals(array.get(i))) {
					listModel.addElement(array.get(i) + "*");
				}else{
					listModel.addElement((String) array.get(i));
				}
			}
			return;
		}
		
		// server forwards message
		if (type.equals("message")) {
			textAreaDisplayMsg.append(message.get("identity") + ": "
					+ message.get("content")+"\r\n");
			textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			return;
		}
		
		
		// server reply of #createroom
		if (type.equals("createroom")) {
			boolean approved = Boolean.parseBoolean((String)message.get("approved"));
			String temp_room = (String)message.get("roomid");
			if (!approved) {
				textAreaDisplayMsg.append("Create room " + temp_room + " failed.\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			else {
				textAreaDisplayMsg.append("Room " + temp_room + " is created.\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			return;
		}
		
		// server reply of # deleteroom
		if (type.equals("deleteroom")) {
			boolean approved = Boolean.parseBoolean((String)message.get("approved"));
			String temp_room = (String)message.get("roomid");
			if (!approved) {
				textAreaDisplayMsg.append("Delete room " + temp_room + " failed.\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			else {
				textAreaDisplayMsg.append("Room " + temp_room + " is deleted.\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			return;
		}
		
		// server directs the client to another server
		if (type.equals("route")) {
			String temp_room = (String)message.get("roomid");
			String host = (String)message.get("host");
			int port = Integer.parseInt((String)message.get("port"));
			
			// connect to the new server
			if (debug) {
				textAreaDisplayMsg.append("Connecting to server " + host + ":" + port+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			System.setProperty("javax.net.ssl.trustStore", "/Users/apple/Desktop/mykeystore");
			SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			SSLSocket temp_socket = (SSLSocket) sslsocketfactory.createSocket(host, port);
			
			// send #movejoin
			DataOutputStream out = new DataOutputStream(temp_socket.getOutputStream());
			JSONObject request = ClientMessages.getMoveJoinRequest(state.getIdentity(), state.getRoomId(), temp_room);
			if (debug) {
				textAreaDisplayMsg.append("Sending: " + request.toJSONString()+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			send(out, request);
			
			// wait to receive serverchange
			BufferedReader temp_in = new BufferedReader(new InputStreamReader(temp_socket.getInputStream()));
			JSONObject obj = (JSONObject) parser.parse(temp_in.readLine());
			
			if (debug) {
				textAreaDisplayMsg.append("Receiving: " + obj.toJSONString()+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			
			// serverchange received and switch server
			if (obj.get("type").equals("serverchange") && obj.get("approved").equals("true")) {
				messageSendThread.switchServer(temp_socket, out);
				switchServer(temp_socket, temp_in);
				String serverid = (String)obj.get("serverid");
				textAreaDisplayMsg.append(state.getIdentity() + " switches to server " + serverid+"\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			// receive invalid message
			else {
				temp_in.close();
				out.close();
				temp_socket.close();
				textAreaDisplayMsg.append("Server change failed\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
			return;
		}
		
		if (debug) {
			textAreaDisplayMsg.append("Unknown Message: " + message+"\r\n");
			textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
		}
	}
	
	public void switchServer(SSLSocket temp_socket, BufferedReader temp_in) throws IOException {
		in.close();
		in = temp_in;
		sslsocket.close();
		sslsocket = temp_socket;
		textFieldHostName.setText(sslsocket.getInetAddress().getHostAddress().toString());
		textFieldPort.setText(""+sslsocket.getPort());
	}

	private void send(DataOutputStream out, JSONObject obj) throws IOException {
		out.write((obj.toJSONString() + "\n").getBytes("UTF-8"));
		out.flush();
	}
}
