package chatSystem.client;

public class State {

	private String identity;
	private String password;
	private String username;
	private String roomId;
	
	public State(String identity, String username, String password, String roomId) {
		this.identity = identity;
		this.username = username;
		this.password = password;
		this.roomId = roomId;
	}
	
	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return username;
	}

	public synchronized String getRoomId() {
		return roomId;
	}
	
	public synchronized void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	
	public String getIdentity() {
		return identity;
	}
	
}
