package chatSystem.client;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;

import javax.net.ssl.SSLSocket;
import javax.swing.JTextArea;

import org.json.simple.JSONObject;

public class MessageSendThread implements Runnable {

	private SSLSocket sslsocket;

	private DataOutputStream out;

	private State state;

	private boolean debug;

	// reading from console
	private BlockingQueue<String> messageQueue;
	private JTextArea textAreaDisplayMsg;

	public MessageSendThread(SSLSocket sslsocket, State state, boolean debug, BlockingQueue<String> messageQueue, 
			JTextArea textAreaDisplayMsg)
			throws IOException {
		this.sslsocket = sslsocket;
		this.state = state;
		out = new DataOutputStream(sslsocket.getOutputStream());
		this.debug = debug;
		this.messageQueue = messageQueue;
		this.textAreaDisplayMsg = textAreaDisplayMsg;
	}

	@Override
	public void run() {

		try {
			// send the #newidentity command
			String msg = "#newidentity " + state.getIdentity() + " " + state.getUsername() + " " + state.getPassword();
			MessageSend(sslsocket, msg);
		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		try {
			while (true) {
				String msg = messageQueue.take();
				//textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				MessageSend(sslsocket, msg);
			}
		} catch (Exception e) {
			textAreaDisplayMsg.append("Communication Error: " + e.getMessage()+"\r\n");;
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			System.exit(1);
		}

	}

	private void send(JSONObject obj) throws IOException {
		if (debug) {
			textAreaDisplayMsg.append("Sending: " + obj.toJSONString()+"\r\n");
			textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
		}
		out.write((obj.toJSONString() + "\n").getBytes("UTF-8"));
		out.flush();
	}

	// send command and check validity
	public void MessageSend(Socket socket, String msg) throws IOException {
		JSONObject sendToServer = new JSONObject();
		String[] array = msg.split(" ");
		if (!array[0].startsWith("#")) {
			sendToServer = ClientMessages.getMessage(msg);
			send(sendToServer);
		} else if (array.length == 1) {
			if (array[0].startsWith("#list")) {
				sendToServer = ClientMessages.getListRequest();
				send(sendToServer);
			} else if (array[0].startsWith("#quit")) {
				sendToServer = ClientMessages.getQuitRequest();
				send(sendToServer);
			} else if (array[0].startsWith("#who")) {
				sendToServer = ClientMessages.getWhoRequest();
				send(sendToServer);
			} else {
				textAreaDisplayMsg.append("Invalid command!\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
		} else if (array.length == 2) {
			if (array[0].startsWith("#joinroom")) {
				sendToServer = ClientMessages.getJoinRoomRequest(array[1]);
				send(sendToServer);
			} else if (array[0].startsWith("#createroom")) {
				sendToServer = ClientMessages.getCreateRoomRequest(array[1]);
				send(sendToServer);
			} else if (array[0].startsWith("#deleteroom")) {
				sendToServer = ClientMessages.getDeleteRoomRequest(array[1]);
				send(sendToServer);
			} else {
				textAreaDisplayMsg.append("Invalid command!\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
		}else if(array.length == 4){
			if (array[0].startsWith("#newidentity")) {
				sendToServer = ClientMessages.getNewIdentityRequest(array[1], array[2], array[3]);
				send(sendToServer);
			}else {
				textAreaDisplayMsg.append("Invalid command!\r\n");
				textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
				textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
			}
		}else {
			textAreaDisplayMsg.append("Invalid command!\r\n");
			textAreaDisplayMsg.append("[" + state.getRoomId() + "] " + state.getIdentity() + "> ");
			textAreaDisplayMsg.setCaretPosition(textAreaDisplayMsg.getText().length());
		}

	}

	public void switchServer(SSLSocket temp_socket, DataOutputStream temp_out) throws IOException {
		// switch server initiated by the receiving thread
		// need to use synchronize
		synchronized (out) {
			out.close();
			out = temp_out;
		}
		sslsocket = temp_socket;
	}
}
