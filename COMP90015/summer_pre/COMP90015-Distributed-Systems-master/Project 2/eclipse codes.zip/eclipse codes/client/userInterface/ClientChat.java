package chatSystem.client.userInterface;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;

import chatSystem.client.MessageReceiveThread;
import chatSystem.client.MessageSendThread;
import chatSystem.client.State;
import javax.swing.JPasswordField;

public class ClientChat extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1863609454096839330L;
	private JPanel contentPane;
	private JTextField textFieldRoomID;
	private JButton btnClearMsg;
	private JButton btnSendMsg;
	private JButton btnCreateRoom;
	private JButton btnDeleteRoom;
	private JComboBox<String> cboRoomList = new JComboBox<String>();
	private JButton btnJoinRoom;
	private JButton btnRoomList;
	private JList<String> listChatMember;
	private DefaultListModel<String> listModel;
	private JButton btnWho;
	private JTextArea textAreaDisplayMsg;
	private JTextArea textAreaInputMsg;
	private JPanel panelLogin;
	private JTextField textFieldHostName;
	private JTextField textFieldPort;
	private JTextField textFieldUserName;
	private JTextField textFieldIdentity;
	private JButton btnLogin;
	private JButton btnQuit;
	private JPanel panelRoom;
	private JPasswordField textFieldPassword;

	
	SSLSocketFactory sslsocketfactory = null;
	SSLSocket sslsocket = null;
	DataOutputStream out;
	State state;
	String identity = null;
	boolean debug = false;
	BlockingQueue<String> messageQueue = new LinkedBlockingQueue<String>();
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientChat frame = new ClientChat();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientChat() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 555, 480);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panelMsg = new JPanel();
		panelMsg.setBorder(new TitledBorder(null, "Chat Info", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelMsg.setToolTipText("");
		panelMsg.setBounds(6, 90, 303, 361);
		contentPane.add(panelMsg);
		panelMsg.setLayout(null);

		textAreaDisplayMsg = new JTextArea();
		JScrollPane scrollDisplay = new JScrollPane(textAreaDisplayMsg);
		scrollDisplay.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollDisplay.setBounds(6, 16, 291, 200);
		textAreaDisplayMsg.setFont(new Font("Arial", Font.PLAIN, 12));
		textAreaDisplayMsg.setEditable(false);
		textAreaDisplayMsg.setWrapStyleWord(true);
		textAreaDisplayMsg.setLineWrap(true);
		textAreaDisplayMsg.setBounds(6, 16, 291, 200);
		panelMsg.add(scrollDisplay);

		textAreaInputMsg = new JTextArea();
		JScrollPane scrollInput = new JScrollPane(textAreaInputMsg);
		scrollInput.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollInput.setBounds(6, 229, 291, 85);
		textAreaInputMsg.setFont(new Font("Arial", Font.PLAIN, 12));
		textAreaInputMsg.setWrapStyleWord(true);
		textAreaInputMsg.setLineWrap(true);
		textAreaInputMsg.setBounds(6, 229, 291, 85);
		panelMsg.add(scrollInput);

		btnClearMsg = new JButton("Clear");
		btnClearMsg.setBounds(16, 326, 75, 29);
		panelMsg.add(btnClearMsg);
		btnClearMsg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAreaInputMsg.setText("");
				textAreaInputMsg.requestFocusInWindow();
			}
		});
		btnClearMsg.setFont(new Font("Arial", Font.PLAIN, 12));

		btnSendMsg = new JButton("Send");
		btnSendMsg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = textAreaInputMsg.getText();
				messageQueue.add(msg);
				textAreaInputMsg.setText("");
				textAreaInputMsg.requestFocusInWindow();
			}
		});
		btnSendMsg.setBounds(200, 326, 75, 29);
		panelMsg.add(btnSendMsg);
		btnSendMsg.setFont(new Font("Arial", Font.PLAIN, 12));

		panelLogin = new JPanel();
		panelLogin.setBorder(new TitledBorder(null, "Login Info", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelLogin.setBounds(12, 6, 528, 72);
		panelLogin.setLayout(null);
		contentPane.add(panelLogin);

		JLabel labHostName = new JLabel("Hostname: ");
		labHostName.setBounds(6, 15, 80, 16);
		panelLogin.add(labHostName);

		textFieldHostName = new JTextField();
		textFieldHostName.setText("localhost");
		textFieldHostName.setColumns(10);
		textFieldHostName.setBounds(87, 10, 95, 26);
		panelLogin.add(textFieldHostName);

		JLabel labPort = new JLabel("Port: ");
		labPort.setBounds(194, 15, 40, 16);
		panelLogin.add(labPort);

		textFieldPort = new JTextField();
		textFieldPort.setText("4444");
		textFieldPort.setColumns(10);
		textFieldPort.setBounds(246, 10, 60, 26);
		panelLogin.add(textFieldPort);

		JLabel labUserName = new JLabel("Username: ");
		labUserName.setFont(new Font("Arial", Font.PLAIN, 12));
		labUserName.setBounds(6, 44, 80, 16);
		panelLogin.add(labUserName);

		textFieldUserName = new JTextField();
		textFieldUserName.setText("kaiqingw");
		textFieldUserName.setFont(new Font("Arial", Font.PLAIN, 12));
		textFieldUserName.setColumns(10);
		textFieldUserName.setBounds(87, 39, 130, 26);
		panelLogin.add(textFieldUserName);

		JLabel labPassword = new JLabel("Password: ");
		labPassword.setFont(new Font("Arial", Font.PLAIN, 12));
		labPassword.setBounds(247, 44, 80, 16);
		panelLogin.add(labPassword);

		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// get login info
					String hostname = null;
					int port;
					String username = "use";
					String password = "pas";
					hostname = textFieldHostName.getText();
					username = textFieldUserName.getText();
					identity = textFieldIdentity.getText();
					password = String.valueOf(textFieldPassword.getPassword());
					try {
						port = Integer.parseInt(textFieldPort.getText());
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(ClientChat.this, "Port Number Error!", "Info Error",
								JOptionPane.ERROR_MESSAGE);
						textFieldPort.setText("");
						textFieldPort.requestFocusInWindow();
						return;
					}

					if (hostname.isEmpty() || username.isEmpty() || password.isEmpty() || identity.isEmpty()) {
						JOptionPane.showMessageDialog(ClientChat.this, "Input Login info Please!", "Info Error",
								JOptionPane.ERROR_MESSAGE);
						errorProcess();
						return;
					}
					InetAddress address = InetAddress.getByName(hostname);

					// connect with server
					try {
						System.setProperty("javax.net.ssl.trustStore", "/Users/apple/Desktop/mykeystore");
						sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
						sslsocket = (SSLSocket) sslsocketfactory.createSocket(address, port);
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(ClientChat.this, "Input correct Login Info please!",
								"Login Error", JOptionPane.ERROR_MESSAGE);
						errorProcess();
						return;
					}

					State state = new State(identity, username, password, "");

					MessageSendThread messageSendThread = new MessageSendThread(sslsocket, state, debug, messageQueue, textAreaDisplayMsg);
					Thread sendThread = new Thread(messageSendThread);
					sendThread.start();
					// start receiving thread
					Thread receiveThread = new Thread(new MessageReceiveThread(sslsocket, state, messageSendThread,
							debug, textAreaDisplayMsg, listModel, cboRoomList, btnLogin, textFieldHostName, textFieldPort));
					receiveThread.start();
					
					textFieldHostName.setEditable(false);
					textFieldPort.setEditable(false);
					textFieldIdentity.setEditable(false);
					textFieldUserName.setEditable(false);
					textFieldPassword.setEditable(false);
				} catch (UnknownHostException e1) {
					JOptionPane.showMessageDialog(ClientChat.this, "Unknown host!", "Login Error",
							JOptionPane.ERROR_MESSAGE);
				} catch (IOException e1) {
					String msg = "Communication Error: " + e1.getMessage();
					JOptionPane.showMessageDialog(ClientChat.this, msg, "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnLogin.setFont(new Font("Arial", Font.PLAIN, 12));
		btnLogin.setBounds(442, 38, 80, 29);
		panelLogin.add(btnLogin);

		btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = "#quit";
				messageQueue.add(msg);
			}
		});
		btnQuit.setFont(new Font("Arial", Font.PLAIN, 12));
		btnQuit.setBounds(442, 10, 80, 29);
		panelLogin.add(btnQuit);
		
		textFieldPassword = new JPasswordField();
		textFieldPassword.setToolTipText("123456");
		textFieldPassword.setBounds(313, 38, 130, 26);
		panelLogin.add(textFieldPassword);
		
		JLabel labIdentity = new JLabel("Identity: ");
		labIdentity.setBounds(318, 15, 61, 16);
		panelLogin.add(labIdentity);
		
		textFieldIdentity = new JTextField();
		textFieldIdentity.setText("adel");
		textFieldIdentity.setBounds(382, 10, 61, 26);
		panelLogin.add(textFieldIdentity);
		textFieldIdentity.setColumns(10);

		panelRoom = new JPanel();
		panelRoom.setBorder(new TitledBorder(null, "Room Info", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelRoom.setBounds(326, 90, 223, 361);
		contentPane.add(panelRoom);
		panelRoom.setLayout(null);

		JLabel labInputRoomID = new JLabel("Input RoomID: ");
		labInputRoomID.setBounds(6, 31, 95, 16);
		panelRoom.add(labInputRoomID);

		textFieldRoomID = new JTextField();
		textFieldRoomID.setBounds(107, 26, 109, 26);
		panelRoom.add(textFieldRoomID);
		textFieldRoomID.setColumns(10);

		btnCreateRoom = new JButton("Create Room");
		btnCreateRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String roomId = textFieldRoomID.getText().trim();
				String msg = "#createroom "+roomId;
				if(roomId.isEmpty()){
					JOptionPane.showMessageDialog(ClientChat.this, "Please input room id", "Error", JOptionPane.ERROR_MESSAGE);
					textFieldRoomID.requestFocusInWindow();
					return;
				}
				messageQueue.add(msg);
				textFieldRoomID.setText("");
			}
		});
		btnCreateRoom.setBounds(6, 59, 101, 29);
		panelRoom.add(btnCreateRoom);
		btnCreateRoom.setFont(new Font("Arial", Font.PLAIN, 12));

		btnDeleteRoom = new JButton("Delete Room");
		btnDeleteRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String roomId = textFieldRoomID.getText().trim();
				String msg = "#deleteroom "+roomId;
				if(roomId.isEmpty()){
					JOptionPane.showMessageDialog(ClientChat.this, "Please input room id", "Error", JOptionPane.ERROR_MESSAGE);
					textFieldRoomID.requestFocusInWindow();
					return;
				}
				messageQueue.add(msg);
				textFieldRoomID.setText("");
			}
		});
		btnDeleteRoom.setBounds(117, 59, 96, 29);
		panelRoom.add(btnDeleteRoom);
		btnDeleteRoom.setFont(new Font("Arial", Font.PLAIN, 12));

		JLabel labRoomList = new JLabel("Room List: ");
		labRoomList.setBounds(6, 91, 75, 16);
		panelRoom.add(labRoomList);
		cboRoomList.setBounds(89, 87, 123, 27);
		panelRoom.add(cboRoomList);

		btnJoinRoom = new JButton("Join Room");
		btnJoinRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg;
				try{
					msg = "#joinroom " + cboRoomList.getSelectedItem().toString();
				}catch(Exception e1){
					JOptionPane.showMessageDialog(ClientChat.this, "Please select Room!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				messageQueue.add(msg);
			}
		});
		btnJoinRoom.setBounds(6, 119, 89, 29);
		panelRoom.add(btnJoinRoom);
		btnJoinRoom.setFont(new Font("Arial", Font.PLAIN, 12));

		btnRoomList = new JButton("ReNew List");
		btnRoomList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = "#list ";
				messageQueue.add(msg);
				JOptionPane.showMessageDialog(ClientChat.this, "Chat Room List update!", "Message", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnRoomList.setBounds(114, 119, 96, 29);
		panelRoom.add(btnRoomList);
		btnRoomList.setFont(new Font("Arial", Font.PLAIN, 12));

		JLabel labChatRoomMember = new JLabel("Chat Room Member: ");
		labChatRoomMember.setBounds(16, 154, 139, 16);
		panelRoom.add(labChatRoomMember);
		labChatRoomMember.setFont(new Font("Arial", Font.PLAIN, 12));

		listModel = new DefaultListModel<String>();
		listChatMember = new JList<String>(listModel);
		listChatMember.setBounds(58, 184, 133, 130);
		panelRoom.add(listChatMember);
		listChatMember.setFont(new Font("Arial", Font.PLAIN, 12));

		btnWho = new JButton("ReNew Member");
		btnWho.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = "#who";
				messageQueue.add(msg);
				JOptionPane.showMessageDialog(ClientChat.this, "Room Member update!", "Message", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnWho.setBounds(68, 326, 123, 29);
		panelRoom.add(btnWho);
		btnWho.setFont(new Font("Arial", Font.PLAIN, 12));

	}

	private void errorProcess() {
		textFieldHostName.setText("");
		textFieldPort.setText("");
		textFieldIdentity.setText("");
		textFieldUserName.setText("");
		textFieldPassword.setText("");
		textFieldHostName.requestFocusInWindow();
	}
}
