package chatSystem.server.cmdLineArgs;

import org.kohsuke.args4j.Option;

public class CmdLineArgs {
	@Option(required = true, name = "-n", aliases = {"--serverName"}, usage = "ServerName")
	private String serverName;
	
	@Option(required = true, name = "-l", aliases = {"--configFile"}, usage = "config")
	private String configFileName;

	@Option(required = false, name = "-h", aliases = {"--host"}, usage = "Server host address")
	private String serverAddress;
	
	@Option(required = false, name = "-p", aliases = {"--port"}, usage = "Server port number")
	private int serverPort;
	
	@Option(required = false, name = "-c", aliases = {"--coordinationPort"}, usage = "Server coordination port number")
	private int coordinationPort;
	
	public String getServerName() {
		return serverName;
	}

	public String getConfigFileName() {
		return configFileName;
	}
	
	public String getServerAddress() {
		return serverAddress;
	}
	
	public int getServerPort() {
		return serverPort;
	}
	
	public int getCoordinationPort() {
		return coordinationPort;
	}

}
