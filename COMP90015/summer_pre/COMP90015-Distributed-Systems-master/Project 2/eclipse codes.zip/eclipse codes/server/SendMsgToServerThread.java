package chatSystem.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import chatSystem.models.ChatroomInfo;
import chatSystem.models.ServerInfo;

public class SendMsgToServerThread extends Thread {
	private String message;
	private ServerInfo server;
	private BlockingQueue<String> servermessageQueue = null;

	public SendMsgToServerThread(BlockingQueue<String> servermessageQueue, ServerInfo server, String message) {
		this.servermessageQueue = servermessageQueue;
		this.server = server;
		this.message = message;
	}
	
	public SendMsgToServerThread(ServerInfo server, String message) {
		this.server = server;
		this.message = message;
	}

	@Override
	public void run() {
		try {
			System.setProperty("javax.net.ssl.trustStore", "./mykeystore");
			SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			SSLSocket outSocket = (SSLSocket) sslsocketfactory.createSocket(server.getAddress(), server.getManagementPort());
			//Socket outSocket = new Socket(server.getAddress(), server.getManagementPort());
			DataOutputStream out = new DataOutputStream(outSocket.getOutputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(outSocket.getInputStream(), "UTF-8"));
			out.write((message + "\n").getBytes("UTF-8"));
			out.flush();
			if(!(servermessageQueue == null)){
				String feedback = null;
				while((feedback = reader.readLine()) != null){
					servermessageQueue.add(feedback);
				}
			}
			
			outSocket.close();
			out.close();
			reader.close();
		} catch (IOException e1) {
			System.out.println(server.getServerName() + " down");
			int index = -1;
			for(int i = 0;i < Server.serverList.size();i++){
				if(Server.serverList.get(i).getServerName().equals(server.getServerName()))
					index = i;
			}
			ArrayList<String> roomInCrashServer = new ArrayList<String>();
			for (Map.Entry<String, ChatroomInfo> entry : Server.remoteChatrooms.entrySet()) {
				if (entry.getValue().getManagingServer().getServerName().equals(server.getServerName())) {
					roomInCrashServer.add(entry.getKey());
				}
			}
			synchronized(this){
				for(String s:roomInCrashServer){
					Server.remoteChatrooms.remove(s);
				}
				Server.serverList.remove(index);	
			}
		}
	}

}
