package chatSystem.server;

import java.util.ArrayList;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import chatSystem.models.ChatroomInfo;
import chatSystem.models.ServerInfo;

@SuppressWarnings("unchecked")
public class ServerMessages {
	
	public static JSONObject lockIdRequest(String serverId, String identity){
		JSONObject jLockId = new JSONObject();
		jLockId.put("type", "lockidentity");
		jLockId.put("serverid", serverId);
		jLockId.put("identity", identity);
		return jLockId;
	}
	
	public static JSONObject lockIdReply(String serverId, String identity, String locked){
		JSONObject jLockId = new JSONObject();
		jLockId.put("type", "lockidentity");
		jLockId.put("serverid", serverId);
		jLockId.put("identity", identity);
		jLockId.put("locked", locked);
		return jLockId;
	}
	
	public static JSONObject newIdReply(String approved) {
		JSONObject jNewId = new JSONObject();
		jNewId.put("type", "newidentity");
		jNewId.put("approved", approved);
		return jNewId;
	}

	public static JSONObject loginReply(String approved) {
		JSONObject jLogin = new JSONObject();
		jLogin.put("type", "login");
		jLogin.put("approved", approved);
		return jLogin;
	}
	
	public static JSONObject releaseIdRequest(String serverId, String identity) {
		JSONObject jRelease = new JSONObject();
		jRelease.put("type", "releaseidentity");
		jRelease.put("serverid", serverId);
		jRelease.put("identity", identity);
		return jRelease;
	}

	public static JSONObject roomchangeBroadcast(String identity, String former, String roomid) {
		JSONObject jChangeroom = new JSONObject();
		jChangeroom.put("type", "roomchange");
		jChangeroom.put("identity", identity);
		jChangeroom.put("former", former);
		jChangeroom.put("roomid", roomid);
		return jChangeroom;
	}

	public static JSONObject roomListReply() {
		JSONObject jRoomlist = new JSONObject();
		jRoomlist.put("type", "roomlist");
		JSONArray jRooms = new JSONArray();
		// put all room info in to JSONArray
		for (Map.Entry<String, ChatroomInfo> entry : Server.localChatrooms.entrySet()) {
			ChatroomInfo room = entry.getValue();
			jRooms.add(room.getChatRoomId());
		}
		
		for (Map.Entry<String, ChatroomInfo> entry : Server.remoteChatrooms.entrySet()) {
			ChatroomInfo room = entry.getValue();
			jRooms.add(room.getChatRoomId());
		}
		jRoomlist.put("rooms", jRooms);
		return jRoomlist;
	}

	public static JSONObject whoReply(String roomId) {
		JSONObject jRoomInfo = new JSONObject();
		jRoomInfo.put("type", "roomcontents");
		jRoomInfo.put("roomid", roomId);
		JSONArray jIdentities = new JSONArray();
		// TODO: make sure static ArrayList rooms ???
		for (Map.Entry<String, ChatroomInfo> entry : Server.localChatrooms.entrySet()) {
			if (entry.getValue().getChatRoomId().equals(roomId)) {
				ArrayList<String> guests = (entry.getValue()).getUserList();
				for (String name : guests) {
					jIdentities.add(name);
				}
			}
		}
		jRoomInfo.put("identities", jIdentities);
		for (Map.Entry<String, ChatroomInfo> entry : Server.localChatrooms.entrySet()) {
			if (entry.getValue().getChatRoomId().equals(roomId)) {
				jRoomInfo.put("owner", (entry.getValue()).getRooomOwner());
			}
		}

		return jRoomInfo;
	}
	
	public static JSONObject createroomReply(String roomId, String approved) {
		JSONObject jRoomReply = new JSONObject();
		jRoomReply.put("type", "createroom");
		jRoomReply.put("roomid", roomId);
		jRoomReply.put("approved", approved);
		return jRoomReply;		
	}
	
	public static JSONObject lockroomIdRequest(String serverid, String roomid){
		JSONObject jLockRoom = new JSONObject();
		jLockRoom.put("type", "lockroomid");
		jLockRoom.put("serverid", serverid);
		jLockRoom.put("roomid", roomid);
		return jLockRoom;
	}
	
	public static JSONObject lockroomIdReply(String serverid, String roomid, String locked){
		JSONObject jLockRoomReply = new JSONObject();
		jLockRoomReply.put("type", "lockroomid");
		jLockRoomReply.put("serverid", serverid);
		jLockRoomReply.put("roomid", roomid);
		jLockRoomReply.put("locked", locked);
		return jLockRoomReply;
	}
	
	public static JSONObject releaseroomIdRequest(String serverid, String roomid, String approved){
		JSONObject jReleaseRoom = new JSONObject();
		jReleaseRoom.put("type", "releaseroomid");
		jReleaseRoom.put("serverid", serverid);
		jReleaseRoom.put("roomid", roomid);
		jReleaseRoom.put("approved", approved);
		return jReleaseRoom;
	}
	
	public static JSONObject routeReply(String roomid, String host, int port){
		JSONObject jRoute = new JSONObject();
		String strPort = ""+port;
		jRoute.put("type", "route");
		jRoute.put("roomid", roomid);
		jRoute.put("host", host);
		jRoute.put("port", strPort);
		return jRoute;		
	}
	
	public static JSONObject serverChangeReply(String approved, String serverid){
		JSONObject jServerchange = new JSONObject();
		jServerchange.put("type", "serverchange");
		jServerchange.put("approved", approved);
		jServerchange.put("serverid", serverid);
		return jServerchange;
	}
	
	public static JSONObject deleteroomReply(String roomid, String approved){
		JSONObject jDeleteroom = new JSONObject();
		jDeleteroom.put("type", "deleteroom");
		jDeleteroom.put("roomid", roomid);
		jDeleteroom.put("approved", approved);
		return jDeleteroom;
	}
		
	public static JSONObject deleteroomBroadcast(String serverid, String roomid){
		JSONObject jDelete = new JSONObject();
		jDelete.put("type", "deleteroom");
		jDelete.put("serverid", serverid);
		jDelete.put("roomid", roomid);		
		return jDelete;
	}
	
	public static JSONObject messageReply(String identity, String content){
		JSONObject jMessage = new JSONObject();
		jMessage.put("type", "message");
		jMessage.put("identity", identity);
		jMessage.put("content", content);
		return jMessage;
	}
	
	public static JSONObject quitMsg(){
		JSONObject jQuit = new JSONObject();
		jQuit.put("type", "quit");
		return jQuit;
	}
	
	public static JSONObject aliveMsg(String servername){
		JSONObject jAlive = new JSONObject();
		jAlive.put("type", "alive");
		jAlive.put("servername",servername);
		return jAlive;
	}
	
	public static JSONObject newServer(String servername){
		JSONObject jNewServer = new JSONObject();
		jNewServer.put("type", "newserver");
		jNewServer.put("servername",servername);
		return jNewServer;
	}
	
	public static JSONObject newServerReply(String approved){
		JSONObject jNewServerReply = new JSONObject();
		jNewServerReply.put("type", "newserver");
		jNewServerReply.put("approved",approved);
		return jNewServerReply;
	}
	
	public static JSONObject updateServerInfo(ServerInfo server){
		JSONObject jUpdateServerInfo = new JSONObject();
		jUpdateServerInfo.put("type", "updateserver");
		jUpdateServerInfo.put("servername",server.getServerName());
		jUpdateServerInfo.put("address",server.getAddress().getHostAddress().toString());
		jUpdateServerInfo.put("port",""+server.getPort());
		jUpdateServerInfo.put("managementport", ""+server.getManagementPort());
		return jUpdateServerInfo;
	}
	
	public static JSONObject serverUpdateServerInfo(ServerInfo server){
		JSONObject jUpdateServerInfo = new JSONObject();
		jUpdateServerInfo.put("type", "updatebetweenserver");
		jUpdateServerInfo.put("servername",server.getServerName());
		jUpdateServerInfo.put("address",server.getAddress().getHostAddress().toString());
		jUpdateServerInfo.put("port",""+server.getPort());
		jUpdateServerInfo.put("managementport", ""+server.getManagementPort());
		return jUpdateServerInfo;
	}
	
	public static JSONObject updateServerInfoReply() {
		JSONObject jUpdate = new JSONObject();
		jUpdate.put("type", "update");
		JSONArray jRooms = new JSONArray();
		JSONArray jServers = new JSONArray();
		// put all room info in to JSONArray
		for (Map.Entry<String, ChatroomInfo> entry : Server.localChatrooms.entrySet()) {
			ChatroomInfo room = entry.getValue();
			JSONArray jRoom = new JSONArray();
			jRoom.add(room.getChatRoomId());
			jRoom.add(room.getManagingServer().getServerName());
			jRoom.add(room.getManagingServer().getAddress().getHostAddress().toString());
			jRoom.add(""+room.getManagingServer().getPort());
			jRoom.add(""+room.getManagingServer().getManagementPort());
			jRooms.add(jRoom);
		}
		for (Map.Entry<String, ChatroomInfo> entry : Server.remoteChatrooms.entrySet()) {
			ChatroomInfo room = entry.getValue();
			JSONArray jRoom = new JSONArray();
			jRoom.add(room.getChatRoomId());
			jRoom.add(room.getManagingServer().getServerName());
			jRoom.add(room.getManagingServer().getAddress().getHostAddress().toString());
			jRoom.add(""+room.getManagingServer().getPort());
			jRoom.add(""+room.getManagingServer().getManagementPort());
			jRooms.add(jRoom);
		}
		//get all server's info
		for(ServerInfo s:Server.serverList){
			JSONArray jServer = new JSONArray();
			jServer.add(s.getServerName());
			jServer.add(s.getAddress().getHostAddress().toString());
			jServer.add(""+s.getPort());
			jServer.add(""+s.getManagementPort());
			jServers.add(jServer);
		}
		JSONArray jServer = new JSONArray();
		jServer.add(Server.thisServerInfo.getServerName());
		jServer.add(Server.thisServerInfo.getAddress().getHostAddress().toString());
		jServer.add(""+Server.thisServerInfo.getPort());
		jServer.add(""+Server.thisServerInfo.getManagementPort());
		jServers.add(jServer);
		
		jUpdate.put("rooms", jRooms);
		jUpdate.put("servers", jServers);
		
		return jUpdate;
	}
	

}
