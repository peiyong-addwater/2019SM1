package chatSystem.server;

import java.util.concurrent.BlockingQueue;
import chatSystem.models.ServerInfo;

public class BroadcasterThread extends Thread {
	private String message;
	private BlockingQueue<String> servermessageQueue = null;
	
	public BroadcasterThread(BlockingQueue<String> servermessageQueue, String message) {
		this.servermessageQueue = servermessageQueue;
	    this.message = message;
	}
	
	public BroadcasterThread(String message) {
	    this.message = message;
	}
	

	@Override
	public void run() {
		for(ServerInfo otherServer: Server.serverList){
			if(this.servermessageQueue == null){
				SendMsgToServerThread sendMsgToServerThread = new SendMsgToServerThread(otherServer, message);
				sendMsgToServerThread.start();
			}else {
				SendMsgToServerThread sendMsgToServerThread = new SendMsgToServerThread(servermessageQueue ,otherServer, message);
				sendMsgToServerThread.start();
			}
			
		}
		
	}
}
