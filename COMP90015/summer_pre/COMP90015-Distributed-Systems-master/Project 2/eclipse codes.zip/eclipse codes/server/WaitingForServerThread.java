package chatSystem.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;

public class WaitingForServerThread extends Thread {
	private SSLServerSocket serverSocket = null;
	private String serverName;
	
	public WaitingForServerThread(SSLServerSocket serverSocket, String serverName) {
		this.serverSocket = serverSocket;
		this.serverName = serverName;
	}
	
	@Override
	public void run() {
		while(true){
			try {
				//System.out.println(Thread.currentThread().getName() + " - Server listening on port " + serverSocket.getLocalPort() + " for server connection");
				
				SSLSocket socketFromServer = (SSLSocket) serverSocket.accept();
				
				ServerConnection serverConnection = new ServerConnection(socketFromServer, serverName);
				serverConnection.setName("Thread" + serverName);
				serverConnection.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	

}
