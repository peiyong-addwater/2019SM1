package chatSystem.server.authentication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LoginInfoLoader {
	
	public static ArrayList<LoginInfo> loadLoginInfo() {
		ArrayList<LoginInfo> loginInfoList = new ArrayList<LoginInfo>();
		LoginInfo login = null;
		try {
			String filename = "./predefinedUser";
			BufferedReader fileReader = new BufferedReader(new FileReader(filename));
			String loginInfo = fileReader.readLine();
			
			while(loginInfo != null) {
				String[] loginParams = loginInfo.split("\t");
				if(loginParams.length == 2) {
					String username = loginParams[0];
					String password = loginParams[1];
					
					login = new LoginInfo(username, password);
					loginInfoList.add(login);
				}
				loginInfo = fileReader.readLine();
			}
			
			fileReader.close();		
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return loginInfoList;
	}

}
