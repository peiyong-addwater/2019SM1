package chatSystem.server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.kohsuke.args4j.CmdLineParser;
import chatSystem.models.ChatroomInfo;
import chatSystem.models.ServerInfo;
import chatSystem.models.UserInfo;
import chatSystem.server.cmdLineArgs.CmdLineArgs;
import chatSystem.server.config.Config;
import chatSystem.server.config.ConfigLoader;

import chatSystem.server.ClientConnection;
import chatSystem.server.ServerState;

public class Server {
	public static List<ServerInfo> serverList = new ArrayList<ServerInfo>();

	public static Map<String, UserInfo> userMap = new HashMap<String, UserInfo>();
	public static Set<String> lockedUser = new HashSet<String>();
	public static Map<String, String> lockedRequestUser = new HashMap<>();

	public static Map<String, ChatroomInfo> localChatrooms = new HashMap<String, ChatroomInfo>();
	public static Map<String, ChatroomInfo> remoteChatrooms = new HashMap<String, ChatroomInfo>();
	public static Set<String> lockedRoomId = new HashSet<String>();;
	public static Map<String, String> lockedRequestRoomId = new HashMap<>();
	
	public static Set<String> lockedServerId = new HashSet<String>();;

	public static ChatroomInfo mainHall;
	public static ServerInfo thisServerInfo = null;

	public static void main(String[] args) {
		//Specify the keystore details (this can be specified as VM arguments as well)
		//the keystore file contains an application's own certificate and private key
		//keytool -genkey -keystore <keystorename> -keyalg RSA
		System.setProperty("javax.net.ssl.keyStore","./mykeystore");
		//Password to access the private key from the keystore file
		System.setProperty("javax.net.ssl.keyStorePassword","mypassword");
		
		System.setProperty("javax.net.ssl.trustStore", "./mykeystore");
		
		SSLServerSocketFactory sslserversocketfactory = (SSLServerSocketFactory) SSLServerSocketFactory
				.getDefault();
		SSLServerSocket serverSocket = null;
		
		// Object that will store the parsed command line arguments
		CmdLineArgs argsBean = new CmdLineArgs();
		// Parser provided by args4j
		CmdLineParser parser = new CmdLineParser(argsBean);

		String serverName;
		 
		String configFileName;
		ArrayList<Config> serverConfigList;
		boolean isInConfig = false;

		try {
			// Parse the arguments
			parser.parseArgument(args);
			// get all server config info from command line
			serverName = argsBean.getServerName();
			configFileName = argsBean.getConfigFileName();
			serverConfigList = ConfigLoader.loadConfig(configFileName);
			
			for(Config c : serverConfigList){
				if(c.getServerName().equals(serverName))
					isInConfig = true;
			}
			
			if(isInConfig){
				// store server info into server list
				String configserverName;
				InetAddress serverAddress;
				int serverPort;
				int coordinationPort;
				ServerInfo otherServer;
				// save other server into serverinfo list
				for (Config c : serverConfigList) {
					configserverName = c.getServerName();
					serverAddress = InetAddress.getByName(c.getServerAddress());
					serverPort = c.getServerPort();
					coordinationPort = c.getCoordinationPort();

					if (c.getServerName().equals(serverName)) {
						thisServerInfo = new ServerInfo(configserverName, serverAddress, serverPort, coordinationPort);
					} else {
						otherServer = new ServerInfo(configserverName, serverAddress, serverPort, coordinationPort);
						serverList.add(otherServer);
						ChatroomInfo otherMainHall = new ChatroomInfo("MainHall-" + otherServer.getServerName(), "", otherServer);
						Server.remoteChatrooms.put(otherMainHall.getChatRoomId(), otherMainHall);
					}
				}
			}else{
				// server id not in config files
				if(args.length != 10){
					System.out.println("Server name not exist in config file, Please in put server config info!");
					System.exit(0);
				}
				
				InetAddress serverAddress = null;
				int serverPort = 0;
				int coordinationPort = 0;
				ServerInfo otherServer;
				try{
					serverAddress = InetAddress.getByName(argsBean.getServerAddress());
					serverPort = argsBean.getServerPort();
					coordinationPort = argsBean.getCoordinationPort();
				}catch(Exception e){
					System.out.println("No enough server config info, Please in put all server info!");
					System.exit(0);
				}
				thisServerInfo = new ServerInfo(serverName, serverAddress, serverPort, coordinationPort);
				for (Config c : serverConfigList) {
					serverAddress = InetAddress.getByName(c.getServerAddress());
					serverPort = c.getServerPort();
					coordinationPort = c.getCoordinationPort();

					otherServer = new ServerInfo(c.getServerName(), serverAddress, serverPort, coordinationPort);
					serverList.add(otherServer);
					ChatroomInfo otherMainHall = new ChatroomInfo("MainHall-" + otherServer.getServerName(), "", otherServer);
					Server.remoteChatrooms.put(otherMainHall.getChatRoomId(), otherMainHall);
				}
			}
			
		} catch (Exception e) {
			System.out.println("Server config Error!");
			return;
		}

		try {
			InetAddress serverAddress = thisServerInfo.getAddress();
			int serverPort = thisServerInfo.getPort();
			int coordinationPort = thisServerInfo.getManagementPort();
			
			serverSocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(serverPort, -1, serverAddress);
			//mainHall = new LocalChatroomInfo("MainHall-" + thisServerInfo.getServerName(), "");
			mainHall = new ChatroomInfo("MainHall-" + thisServerInfo.getServerName(), "" , thisServerInfo);
			Server.localChatrooms.put(mainHall.getChatRoomId(), mainHall);

			System.out.println(
					Thread.currentThread().getName() + " - Server listening on port " + serverPort + " for a connection");
			//thread waiting for server's communication
			
			//ServerSocket serverserverSocket = new ServerSocket(coordinationPort, -1, serverAddress);
			SSLServerSocket serverserverSocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(coordinationPort, -1, serverAddress);
			WaitingForServerThread waitingForServerThread = new WaitingForServerThread(serverserverSocket,thisServerInfo.getServerName());
			waitingForServerThread.setName(thisServerInfo.getServerName());
			waitingForServerThread.start();
			
			// asking other server,check the servername is avaliable #newserver
			JSONObject obj = ServerMessages.newServer(thisServerInfo.getServerName());
			BlockingQueue<String> servermessageQueue = new LinkedBlockingQueue<String>();
			// server name not in config file, check the avaliablity
			if(!isInConfig){
				BroadcasterThread broadcasterThread = new BroadcasterThread(servermessageQueue, obj.toJSONString());
				broadcasterThread.start();
				while(servermessageQueue.size() < 1){
					
				}
				boolean isOk = true;
				for (String s : servermessageQueue) {
					JSONParser p = new JSONParser();
					JSONObject replyObj = (JSONObject) p.parse(s);
					String str = (String) replyObj.get("approved");
					boolean locked = (new Boolean(str)).booleanValue();
					if (locked == false)
						isOk = false;
				}
				
				if(!isOk){
					System.out.println("Server name has beed used!");
					System.exit(0);;
				}
			}
			
			// communication with other server and update its info
			obj = ServerMessages.updateServerInfo(thisServerInfo);
			servermessageQueue = new LinkedBlockingQueue<String>();
			BroadcasterThread broadcasterThread2 = new BroadcasterThread(servermessageQueue, obj.toJSONString());
			broadcasterThread2.start();
			while(servermessageQueue.size() < 1){
				if(Server.serverList.size() == 0)
					break;
			}
			if(servermessageQueue.size() > 0){
				String msg = servermessageQueue.take();
				JSONParser p2 = new JSONParser();
				JSONObject replyObj = (JSONObject) p2.parse(msg);
				
				JSONArray jRooms = (JSONArray) replyObj.get("rooms");
				JSONArray jServers = (JSONArray) replyObj.get("servers");
				// before update the info from other server, clean the dataset
				Server.serverList.clear();
				Server.remoteChatrooms.clear();
				for(int i = 0;i < jServers.size();i++){
					JSONArray server = (JSONArray) jServers.get(i);
					String servername_temp = (String) server.get(0);
					InetAddress serverAddress_temp = InetAddress.getByName((String) server.get(1));
					int serverPort_temp = Integer.parseInt((String) server.get(2));
					int coordinationPort_temp = Integer.parseInt((String) server.get(3));
					
					ServerInfo serverInfo = new ServerInfo(servername_temp, serverAddress_temp, serverPort_temp, coordinationPort_temp);
					Server.serverList.add(serverInfo);
				}
				
				for(int i = 0;i < jRooms.size();i++){
					JSONArray room = (JSONArray) jRooms.get(i);
					String roomId = (String) room.get(0);
					String servername_temp = (String) room.get(1);
					InetAddress serverAddress_temp = InetAddress.getByName((String) room.get(2));
					int serverPort_temp = Integer.parseInt((String) room.get(3));
					int coordinationPort_temp = Integer.parseInt((String) room.get(4));
					
					ServerInfo serverInfo = new ServerInfo(servername_temp, serverAddress_temp, serverPort_temp, coordinationPort_temp);
					ChatroomInfo roomInfo = new ChatroomInfo(roomId,serverInfo);
					Server.remoteChatrooms.put(roomInfo.getChatRoomId(), roomInfo);
				}
			}
			
			// send herat beat to other server, check the state of other server
			Thread heartbeat = new Thread(new SendHeartBeatToServerThread(thisServerInfo.getServerName()));
			heartbeat.start();
			
			// Listen for incoming connections for sever
			while (true) {
				// Accept an incoming client connection request
				
				SSLSocket clientSocket = (SSLSocket) serverSocket.accept();
				System.out.println(Thread.currentThread().getName() + " - Client conection accepted");
 
				ClientConnection clientConnection = new ClientConnection(clientSocket, thisServerInfo.getServerName());
				clientConnection.start();

				// Register the new connection with the client manager
				ServerState.getInstance().clientConnected(clientConnection);
			}

		} catch (Exception e) {
			System.out.println("Server config Error!");
			e.printStackTrace();
		} finally {
			if (serverSocket != null) {
				try {
					serverSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
