package chatSystem.server;

import org.json.simple.JSONObject;

public class SendHeartBeatToServerThread implements Runnable {

	private String servername;
	public SendHeartBeatToServerThread(String servername){
		this.servername = servername;
	}
	private long checkDelay = 100;
	// send heartbeat to every server per 10 seconds
	long keepAliveDelay = 10000;
	private long lastSendTime = System.currentTimeMillis();

	@Override
	public void run() {
		while (true) {
			if (System.currentTimeMillis() - lastSendTime > keepAliveDelay) {
				try {
					JSONObject obj = ServerMessages.aliveMsg(servername);
					BroadcasterThread st = new BroadcasterThread(obj.toJSONString());
					st.start();

					lastSendTime = System.currentTimeMillis();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				try {
					Thread.sleep(checkDelay);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
