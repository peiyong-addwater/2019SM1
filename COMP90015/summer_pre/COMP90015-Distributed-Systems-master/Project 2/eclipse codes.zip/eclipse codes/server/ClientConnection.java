package chatSystem.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLSocket;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import chatSystem.models.ChatroomInfo;
import chatSystem.models.UserInfo;
import chatSystem.server.ClientConnection;
import chatSystem.server.ClientMessageReader;
import chatSystem.server.authentication.LoginInfo;
import chatSystem.server.authentication.LoginInfoLoader;

public class ClientConnection extends Thread {
	
	private SSLSocket clientSocket;
	private BufferedReader reader;
	private BufferedWriter writer;
	private BlockingQueue<String> messageQueue;
	private String serverName;
	private boolean run = true;

	public ClientConnection(SSLSocket clientSocket, String serverName) {
		try {
			this.clientSocket = clientSocket;
			reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "UTF-8"));
			writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "UTF-8"));
			messageQueue = new LinkedBlockingQueue<String>();
			this.serverName = serverName;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

		try {
			// thread waiting for client's communication
			ClientMessageReader messageReader = new ClientMessageReader(reader, messageQueue);
			messageReader.setName(this.getName() + "Reader");
			messageReader.start();

			System.out.println(Thread.currentThread().getName() + " - Processing client " + serverName + "  messages");

			while (run) {
				String msg = messageQueue.take();
				System.out.println("Clientconn - Message from client received: " + msg);
				JSONParser parser = new JSONParser();
				JSONObject jMessage = (JSONObject) parser.parse(msg);
				MessageReceive(clientSocket, serverName, jMessage);
			}
			clientSocket.close();
			ServerState.getInstance().clientDisconnected(this);
			System.out.println(Thread.currentThread().getName() + " - Client " + serverName + " disconnected");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void MessageReceive(Socket socket, String serverName, JSONObject jMessage) throws Exception {
		String type = (String) jMessage.get("type");
		JSONObject obj;
		// process new identity #newidentity
		synchronized(this){
			if (type.equals("newidentity")) {
				String identity = (String) jMessage.get("identity");
				String username = (String) jMessage.get("username");
				String password = (String) jMessage.get("password");
				String pattern = "^[A-Za-z]{3,16}$";
				Pattern p = Pattern.compile(pattern);
				Matcher m = p.matcher(identity);
				// check the user login info
				ArrayList<LoginInfo> loginInfoList = LoginInfoLoader.loadLoginInfo();
				boolean isLoginInfoOk = false;
				for(LoginInfo login: loginInfoList){
					if(login.getUsername().equals(username) && login.getPassword().equals(password))
						isLoginInfoOk = true;
				}
				
				if(!isLoginInfoOk){
					obj = ServerMessages.loginReply("false");
					write(obj);
					return;
				}
				
				// check identity is in right pattern
				if (!m.find()) {
					obj = ServerMessages.newIdReply("false");
					write(obj);
					return;
				}
				// check identity is availiable
				if (Server.userMap.containsKey(identity) || Server.lockedUser.contains(identity)) {
					obj = ServerMessages.newIdReply("false");
					write(obj);
					return;
				} else {
					Server.lockedUser.add(identity);
					obj = ServerMessages.lockIdRequest(serverName, identity);
					BlockingQueue<String> servermessageQueue = new LinkedBlockingQueue<String>();
					servermessageQueue = BroadcastToServerWithReply(obj);
					boolean isLocked = true;
					while (servermessageQueue.size() < Server.serverList.size()) {

					}
					for (String s : servermessageQueue) {
						JSONParser parser = new JSONParser();
						JSONObject replyObj = (JSONObject) parser.parse(s);
						String str = (String) replyObj.get("locked");
						boolean locked = (new Boolean(str)).booleanValue();
						if (locked == false)
							isLocked = false;
					}
					if (isLocked) {
						obj = ServerMessages.newIdReply("true");
						this.setName(identity);
						UserInfo newUser = new UserInfo(identity, Server.mainHall, clientSocket);
						Server.userMap.put(identity, newUser);
						Server.mainHall.setUserList(identity);
						write(obj);
						obj = ServerMessages.releaseIdRequest(serverName, identity);
						BroadcastToServer(obj);
						Server.lockedUser.remove(identity);
						obj = ServerMessages.roomchangeBroadcast(identity, "", Server.mainHall.getChatRoomId());
						BroadcastToOtherClientInSameRoom(obj, Server.mainHall.getChatRoomId());

						return;
					} else {
						Server.lockedUser.remove(identity);
						obj = ServerMessages.newIdReply("false");
						write(obj);
						return;
					}
				}
			}
		}
		

		// process roomlist #list
		if (type.equals("list")) {
			obj = ServerMessages.roomListReply();
			write(obj);
			return;
		}

		// process room member #who
		if (type.equals("who")) {
			String chatRoomId = null;
			for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
				if (entry.getValue().getSockte() == clientSocket) {
					chatRoomId = entry.getValue().getCurrentChatroom().getChatRoomId();
				}
			}
			obj = ServerMessages.whoReply(chatRoomId);
			write(obj);
			return;
		}

		// process create room #createroom
		synchronized(this){
			if (type.equals("createroom")) {
				// check roomid is in right pattern
				String roomId = (String) jMessage.get("roomid");
				String identity = null;
				String perviouslyRoom = null;
				String pattern = "^[A-Za-z]{3,16}$";
				Pattern p = Pattern.compile(pattern);
				Matcher m = p.matcher(roomId);
				if (!m.find()) {
					obj = ServerMessages.createroomReply(roomId, "false");
					write(obj);
					return;
				}

				// find current user's name
				for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
					if (entry.getValue().getSockte() == clientSocket) {
						identity = entry.getValue().getUserName();
						perviouslyRoom = entry.getValue().getCurrentChatroom().getChatRoomId();
					}
				}

				// check useris not the owner of another room
				for (Map.Entry<String, ChatroomInfo> entry : Server.localChatrooms.entrySet()) {
					if (entry.getValue().getRooomOwner().equals(identity)) {
						obj = ServerMessages.createroomReply(roomId, "false");
						write(obj);
						return;
					}
				}

				// check roomid is availiable
				if (Server.localChatrooms.containsKey(roomId) || Server.remoteChatrooms.containsKey(roomId)
						|| Server.lockedRoomId.contains(roomId)) {
					obj = ServerMessages.createroomReply(roomId, "false");
					write(obj);
					return;
				} else {
					Server.lockedRoomId.add(roomId);
					obj = ServerMessages.lockroomIdRequest(serverName, roomId);
					BlockingQueue<String> servermessageQueue = new LinkedBlockingQueue<String>();
					servermessageQueue = BroadcastToServerWithReply(obj);
					while (servermessageQueue.size() < Server.serverList.size()) {

					}
					boolean isLocked = true;
					for (String s : servermessageQueue) {
						JSONParser parser = new JSONParser();
						JSONObject replyObj = (JSONObject) parser.parse(s);
						String str = (String) replyObj.get("locked");
						boolean locked = (new Boolean(str)).booleanValue();
						if (locked == false)
							isLocked = false;
					}
					if (isLocked) {
						obj = ServerMessages.createroomReply(roomId, "true");
						// create new room
						ChatroomInfo newRoom = new ChatroomInfo(roomId, identity, Server.thisServerInfo);
						newRoom.setUserList(identity);
						Server.userMap.get(identity).setCurrentChatroom(newRoom);
						Server.localChatrooms.put(roomId, newRoom);
						Server.localChatrooms.get(perviouslyRoom).deleteUser(identity);
						write(obj);
						obj = ServerMessages.releaseroomIdRequest(serverName, roomId, "true");
						BroadcastToServer(obj);
						Server.lockedRoomId.remove(roomId);
						obj = ServerMessages.roomchangeBroadcast(identity, perviouslyRoom, roomId);
						write(obj);
						BroadcastToOtherClientInSameRoom(obj, perviouslyRoom);
						return;
					} else {
						Server.lockedRoomId.remove(roomId);
						obj = ServerMessages.createroomReply(roomId, "false");
						write(obj);
						obj = ServerMessages.releaseroomIdRequest(serverName, roomId, "false");
						BroadcastToServer(obj);
						return;
					}
				}
			}
		}
		

		// process join room #join
		if (type.equals("join")) {
			String roomId = (String) jMessage.get("roomid");
			String identity = null;
			String currentRoomOwner = null;
			String perviousRoom = null;
			// find current user's name
			for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
				if (entry.getValue().getSockte() == clientSocket) {
					identity = entry.getValue().getUserName();
					currentRoomOwner = entry.getValue().getCurrentChatroom().getRooomOwner();
					perviousRoom = entry.getValue().getCurrentChatroom().getChatRoomId();
				}
			}
			// check user is the owner of current room
			if (identity.equals(currentRoomOwner)) {
				obj = ServerMessages.roomchangeBroadcast(identity, roomId, roomId);
				write(obj);
				return;
			}
			// check join room is exist
			if (!Server.localChatrooms.containsKey(roomId) && !Server.remoteChatrooms.containsKey(roomId)) {
				obj = ServerMessages.roomchangeBroadcast(identity, roomId, roomId);
				write(obj);
				return;
			}
			// check had in the join room
			if (roomId.equals(perviousRoom)) {
				obj = ServerMessages.roomchangeBroadcast(identity, roomId, roomId);
				write(obj);
				return;
			}
			// room in the same server
			if (Server.localChatrooms.containsKey(roomId)) {
				Server.localChatrooms.get(perviousRoom).deleteUser(identity);
				Server.localChatrooms.get(roomId).getUserList().add(identity);

				for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
					if (entry.getValue().getSockte() == clientSocket) {
						entry.getValue().setCurrentChatroom(Server.localChatrooms.get(roomId));
					}
				}
				obj = ServerMessages.roomchangeBroadcast(identity, perviousRoom, roomId);
				BroadcastToOtherClientInSameRoom(obj, perviousRoom);
				BroadcastToOtherClientInSameRoom(obj, roomId);
				return;
			}
			// room in the other server
			if (Server.remoteChatrooms.containsKey(roomId)) {
				String joinAddress = Server.remoteChatrooms.get(roomId).getManagingServer().getAddress()
						.getHostAddress();
				int joinPort = Server.remoteChatrooms.get(roomId).getManagingServer().getPort();

				obj = ServerMessages.routeReply(roomId, joinAddress, joinPort);
				write(obj);
				Server.localChatrooms.get(perviousRoom).deleteUser(identity);
				Server.userMap.remove(identity);
				obj = ServerMessages.roomchangeBroadcast(identity, perviousRoom, roomId);
				BroadcastToOtherClientInSameRoom(obj, perviousRoom);
				run = false;
				return;
			}
		}
		
		// process move join
		if (type.equals("movejoin")) {
			String roomId = (String) jMessage.get("roomid");
			String identity = (String) jMessage.get("identity");
			String perviousRoom = (String) jMessage.get("former");
			this.setName(identity);
			//return server change message
			
			// roomid does not exist
			if (!Server.localChatrooms.containsKey(roomId)) {
				Server.localChatrooms.get(Server.mainHall.getChatRoomId()).setUserList(identity);
				UserInfo joinUser = new UserInfo(identity, Server.mainHall, clientSocket);
				Server.userMap.put(identity, joinUser);
			}
			// roomid in the server
			if (Server.localChatrooms.containsKey(roomId)) {
				Server.localChatrooms.get(roomId).setUserList(identity);
				UserInfo joinUser = new UserInfo(identity, Server.localChatrooms.get(roomId), clientSocket);
				Server.userMap.put(identity, joinUser);
			}
			obj = ServerMessages.serverChangeReply("true", Server.thisServerInfo.getServerName());
			write(obj);
			obj = ServerMessages.roomchangeBroadcast(identity, perviousRoom, Server.userMap.get(identity).getCurrentChatroom().getChatRoomId());
			BroadcastToOtherClientInSameRoom(obj, Server.userMap.get(identity).getCurrentChatroom().getChatRoomId());
			
		}
		// process delete room #deleteroom
		if (type.equals("deleteroom")) {
			String roomId = (String) jMessage.get("roomid");
			String identity = null;
			String currentRoomOwner = null;
			String currentRoom = null;
			// find current user's name
			for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
				if (entry.getValue().getSockte() == clientSocket) {
					identity = entry.getValue().getUserName();
					currentRoomOwner = entry.getValue().getCurrentChatroom().getRooomOwner();
					currentRoom = entry.getValue().getCurrentChatroom().getChatRoomId();
				}
			}
			// room id not exit
			if (!Server.localChatrooms.containsKey(roomId)) {
				obj = ServerMessages.deleteroomReply(roomId, "false");
				write(obj);
				return;
			}
			// if want to delete Mainhall
			if (roomId.equals(Server.mainHall.getChatRoomId())) {
				obj = ServerMessages.deleteroomReply(roomId, "false");
				write(obj);
				return;
			}
			// not success
			if (!currentRoomOwner.equals(identity)) {
				obj = ServerMessages.deleteroomReply(roomId, "false");
				write(obj);
				return;
			}

			// check user is the owner of current room
			if (currentRoomOwner.equals(identity)) {
				obj = ServerMessages.deleteroomBroadcast(serverName, roomId);
				BroadcastToServer(obj);

				//get the user list in the delete Room
				ArrayList<String> deleteRoomUser = new ArrayList<String>();
				for (String s : Server.localChatrooms.get(roomId).getUserList())
					deleteRoomUser.add(s);

				for (int i = 0; i < deleteRoomUser.size(); i++) {
					String s = deleteRoomUser.get(i);

					obj = ServerMessages.roomchangeBroadcast(s, currentRoom, Server.mainHall.getChatRoomId());
					BroadcastToOtherClientInSameRoom(obj, currentRoom);
					BroadcastToOtherClientInSameRoom(obj, Server.mainHall.getChatRoomId());

					Server.userMap.get(s).setCurrentChatroom(Server.mainHall);
					Server.localChatrooms.get(roomId).deleteUser(s);
					Server.localChatrooms.get(Server.mainHall.getChatRoomId()).setUserList(s);
				}

				Server.localChatrooms.remove(roomId);
				return;
			}
		}

		// process message
		if (type.equals("message")) {
			String content = (String) jMessage.get("content");
			String identity = null;
			String currentRoom = null;
			// find current user's name
			for (Map.Entry<String, UserInfo> entry : Server.userMap.entrySet()) {
				if (entry.getValue().getSockte() == clientSocket) {
					identity = entry.getValue().getUserName();
					currentRoom = entry.getValue().getCurrentChatroom().getChatRoomId();
				}
			}
			obj = ServerMessages.messageReply(identity, content);
			BroadcastToOtherClientInSameRoom(obj, currentRoom);
			return;
		}

		// process quit
		if (type.equals("quit")) {
			String identity = this.getName();
			String currentRoomOwner = Server.userMap.get(identity).getCurrentChatroom().getRooomOwner();
			String currentRoom = Server.userMap.get(identity).getCurrentChatroom().getChatRoomId();
			// find current user's name

			boolean isOwner = currentRoomOwner.equals(identity);

			// delete user
			// user not a owner of a room
			if (!isOwner) {
				Server.localChatrooms.get(currentRoom).deleteUser(identity);
				Server.userMap.remove(identity);
				obj = ServerMessages.roomchangeBroadcast(identity, currentRoom, "");
				BroadcastToOtherClientInSameRoom(obj, currentRoom);
				write(obj);
				run = false;
				//clientSocket.close();
				return;
			}

			if (isOwner) {
				Server.localChatrooms.get(currentRoom).deleteUser(identity);
				Server.userMap.remove(identity);
				obj = ServerMessages.roomchangeBroadcast(identity, currentRoom, "");
				BroadcastToOtherClientInSameRoom(obj, currentRoom);
				write(obj);
				obj = ServerMessages.deleteroomBroadcast(serverName, currentRoom);
				BroadcastToServer(obj);

				//get the user list in the delete Room
				ArrayList<String> deleteRoomUser = new ArrayList<String>();
				for (String s : Server.localChatrooms.get(currentRoom).getUserList())
					deleteRoomUser.add(s);

				for (int i = 0; i < deleteRoomUser.size(); i++) {
					String s = deleteRoomUser.get(i);

					obj = ServerMessages.roomchangeBroadcast(s, currentRoom, Server.mainHall.getChatRoomId());
					BroadcastToOtherClientInSameRoom(obj, currentRoom);
					BroadcastToOtherClientInSameRoom(obj, Server.mainHall.getChatRoomId());

					Server.userMap.get(s).setCurrentChatroom(Server.mainHall);
					Server.localChatrooms.get(currentRoom).deleteUser(s);
					Server.localChatrooms.get(Server.mainHall.getChatRoomId()).setUserList(s);
				}
				Server.localChatrooms.remove(currentRoom);
				run = false;
				//clientSocket.close();
				return;
			}
		}

	}

	public BlockingQueue<String> getMessageQueue() {
		return messageQueue;
	}

	public void write(JSONObject jMessage) {
		try {
			writer.write((jMessage.toJSONString() + "\n"));
			writer.flush();
			System.out
					.println(Thread.currentThread().getName() + " - Message sent to client " + jMessage.toJSONString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public BlockingQueue<String> BroadcastToServerWithReply(JSONObject jMessage) throws InterruptedException {
		BlockingQueue<String> servermessageQueue = new LinkedBlockingQueue<String>();
		BroadcasterThread st = new BroadcasterThread(servermessageQueue, jMessage.toJSONString());
		st.start();
		return servermessageQueue;
	}

	public void BroadcastToServer(JSONObject jMessage) throws InterruptedException {
		BroadcasterThread st = new BroadcasterThread(jMessage.toJSONString());
		st.start();
	}

	public void BroadcastToOtherClientInSameRoom(JSONObject jMessage, String roomName) throws Exception {
		ChatroomInfo localroom = Server.localChatrooms.get(roomName);
		ArrayList<String> userList = localroom.getUserList();
		UserInfo user = null;
		BufferedWriter out = null;
		for (String s : userList) {
			user = Server.userMap.get(s);
			out = new BufferedWriter(new OutputStreamWriter(user.getSockte().getOutputStream(), "UTF-8"));
			// DataOutputStream out = new
			// DataOutputStream(user.getSockte().getOutputStream());
			out.write((jMessage.toJSONString() + "\n"));
			out.flush();
		}
	}

}
