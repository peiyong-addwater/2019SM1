package chatSystem.server.config;

public class Config {
	private String serverName;
	private String serverAddress;
	private int serverPort;
	private int coordinationPort;
	
	public Config(String serverName, String serverAddress, int serverPort, int coordinationPort) {
		super();
		this.serverName = serverName;
		this.serverPort = serverPort;
		this.serverAddress = serverAddress;
		this.coordinationPort = coordinationPort;
	}

	public String getServerName() {
		return serverName;
	}


	public String getServerAddress() {
		return serverAddress;
	}

	public int getServerPort() {
		return serverPort;
	}
	
	public int getCoordinationPort() {
		return coordinationPort;
	}
	
	
}
