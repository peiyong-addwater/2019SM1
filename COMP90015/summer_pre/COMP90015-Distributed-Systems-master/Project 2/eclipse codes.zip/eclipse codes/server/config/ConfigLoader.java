package chatSystem.server.config;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class ConfigLoader {
	
	public static ArrayList<Config> loadConfig(String configFileName) {
		ArrayList<Config> serverConfigList = new ArrayList<Config>();
		Config config = null;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(configFileName));
			String configLine = fileReader.readLine();
			
			while(configLine != null) {
				String[] configParams = configLine.split("\t");
				if(configParams.length == 4) {
					String configserverName = configParams[0];
					String serverAddress = configParams[1];
					int serverPort = Integer.parseInt(configParams[2]);
					int coordinationPort = Integer.parseInt(configParams[3]);
					config = new Config(configserverName, serverAddress, serverPort, coordinationPort);
					serverConfigList.add(config);
				}
				configLine = fileReader.readLine();
			}
			
			fileReader.close();		
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return serverConfigList;
	}

}
