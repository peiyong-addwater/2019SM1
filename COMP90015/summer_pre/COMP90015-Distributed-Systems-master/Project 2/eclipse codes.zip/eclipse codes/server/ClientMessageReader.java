package chatSystem.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.SocketException;
import java.util.concurrent.BlockingQueue;

public class ClientMessageReader extends Thread {
	private BufferedReader reader; 
	private BlockingQueue<String> messageQueue;
	
	public ClientMessageReader(BufferedReader reader, BlockingQueue<String> messageQueue) {
		this.reader = reader;
		this.messageQueue = messageQueue;
	}
	
	@Override
	//This thread reads messages from the client's socket input stream
	public void run() {
		
			String clientMsg = null;
			try {
				while ((clientMsg = reader.readLine()) != null) {
					messageQueue.add(clientMsg);
				}
				String quitStr = ServerMessages.quitMsg().toJSONString();
				messageQueue.add(quitStr);
			}catch (SocketException e) {
				String quitStr = ServerMessages.quitMsg().toJSONString();
				messageQueue.add(quitStr);
			}
			catch (IOException e) {
				
			}
		
	}
}
