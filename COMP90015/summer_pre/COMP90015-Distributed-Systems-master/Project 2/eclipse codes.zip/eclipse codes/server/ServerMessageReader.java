package chatSystem.server;

import java.io.BufferedReader;
import java.net.SocketException;
import java.util.concurrent.BlockingQueue;

public class ServerMessageReader extends Thread {
	private BufferedReader reader; 
	private BlockingQueue<String> messageQueue;
	
	public ServerMessageReader(BufferedReader reader, BlockingQueue<String> messageQueue) {
		this.reader = reader;
		this.messageQueue = messageQueue;
	}
	
	@Override
	//This thread reads messages from the client's socket input stream
	public void run() {
		try {
			String clientMsg = null;
			while ((clientMsg = reader.readLine()) != null) {
				messageQueue.add(clientMsg);
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
