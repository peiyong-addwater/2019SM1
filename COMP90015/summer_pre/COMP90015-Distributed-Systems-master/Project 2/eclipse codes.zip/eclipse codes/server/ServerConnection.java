package chatSystem.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.net.ssl.SSLSocket;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import chatSystem.models.ChatroomInfo;
import chatSystem.models.ServerInfo;

public class ServerConnection extends Thread {
	private SSLSocket clientSocket;
	private BufferedReader reader;
	private BufferedWriter writer;
	//This queue holds messages sent by the client or messages intended for the client from other threads
	private BlockingQueue<String> messageQueue;
	private String serverName;
	private boolean run = true;

	public ServerConnection (SSLSocket clientSocket, String serverName) {
		try {
			this.clientSocket = clientSocket;
			reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "UTF-8"));
			writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "UTF-8"));	
			messageQueue = new LinkedBlockingQueue<String>();
			this.serverName = serverName;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		try {
			//Start the server message reader thread
			ServerMessageReader messageReader = new ServerMessageReader(reader, messageQueue);
			messageReader.setName(this.getName() + "Reader");
			messageReader.start();
			
			while(run) {
				String msg = messageQueue.take();
				
				JSONParser parser = new JSONParser();
				JSONObject jMessage = (JSONObject)parser.parse(msg);
				String type = (String)jMessage.get("type");
				if(!type.equals("alive")){
					System.out.println("Serverconn - Message from server received: " + msg);
				}
				
				MessageReceive(clientSocket, serverName, jMessage);	
			}
			clientSocket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void MessageReceive(SSLSocket socket, String serverName, JSONObject jMessage){
		String type = (String)jMessage.get("type");
		JSONObject obj;
		//process lock identity
		if(type.equals("lockidentity")){
			String identity = (String)jMessage.get("identity");
			if(Server.userMap.containsKey(identity) || Server.lockedUser.contains(identity)){
				obj = ServerMessages.lockIdReply(serverName, identity, "false");
				write(obj);
				return;
			}else{
				obj = ServerMessages.lockIdReply(serverName, identity, "true");
				write(obj);
				String lockedserverName = (String)jMessage.get("serverid");
				Server.lockedRequestUser.put(lockedserverName, identity);
				return;
			}
		}
		
		//process release identity
		if(type.equals("releaseidentity")){
			String identity = (String)jMessage.get("identity");
			String lockedserverName = (String)jMessage.get("serverid");
			Server.lockedRequestUser.remove(lockedserverName, identity);
			return;
		}
		
		//process lock roomid
		if(type.equals("lockroomid")){
			String roomId = (String)jMessage.get("roomid");
			String serverId = (String)jMessage.get("serverid");
			
			if(Server.lockedRoomId.contains(roomId)){
				obj = ServerMessages.lockroomIdReply(serverName, roomId, "false");
				write(obj);
				return;
			}else{
				obj = ServerMessages.lockIdReply(serverName, type, "true");
				write(obj);
				Server.lockedRequestRoomId.put(serverId, roomId);
				return;
			}
		}
		
		//process release roomid
		if(type.equals("releaseroomid")){
			String roomId = (String)jMessage.get("roomid");
			String serverId = (String)jMessage.get("serverid");
			String str = (String) jMessage.get("approved");
			boolean approved = (new Boolean(str)).booleanValue();
			if(approved){
				Server.lockedRequestRoomId.remove(serverId, roomId);
				ServerInfo roomManagementServer = null;
				for(ServerInfo server:Server.serverList){
					if(server.getServerName().equals(serverId))
						roomManagementServer = server;
				}
				ChatroomInfo newRoom = new ChatroomInfo(roomId, roomManagementServer);
				Server.remoteChatrooms.put(roomId, newRoom);
				return;
			}else{
				Server.lockedRequestRoomId.remove(serverId, roomId);
				return;
			}
		}
		
		//process deleteroom
		if(type.equals("deleteroom")){
			String roomId = (String)jMessage.get("roomid");
			//String serverId = (String)jMessage.get("serverid");
			Server.remoteChatrooms.remove(roomId);
			return;
		}
		
		//process alive
		if(type.equals("alive")){
			//String servername = (String)jMessage.get("servername");
			//System.out.println("alive "+servername);
			return;
		}
		
		//process newserver
		if(type.equals("newserver")){
			boolean isOk = true;
			String servername = (String)jMessage.get("servername");
			//check servername is locked
			if(Server.lockedServerId.contains(servername)){
				obj = ServerMessages.newServerReply("false");
				write(obj);
				return;
			}else{
				Server.lockedServerId.add(servername);
			}
			//check servername has been used
			if(this.serverName.equals(servername))
				isOk = false;
			for(ServerInfo s:Server.serverList){
				if(s.getServerName().equals(servername))
					isOk = false;
			}
			
			if(isOk){
				obj = ServerMessages.newServerReply("true");
				Server.lockedServerId.remove(servername);
				write(obj);
				return;
			}else{
				obj = ServerMessages.newServerReply("false");
				Server.lockedServerId.remove(servername);
				write(obj);
				return;
			}
		}
		
		//process updateRequest
		if(type.equals("updateserver")){
			ServerInfo newServer = null;
			try {
				String servername = (String)jMessage.get("servername");
				InetAddress serverAddress = InetAddress.getByName((String)jMessage.get("address"));
				int serverPort = Integer.parseInt((String)jMessage.get("port"));
				int coordinationPort = Integer.parseInt((String)jMessage.get("managementport"));
				newServer = new ServerInfo(servername, serverAddress, serverPort, coordinationPort);
			} catch (Exception e) {
				System.out.println("New Server Info Error!");
			}
			
			obj = ServerMessages.updateServerInfoReply();
			write(obj);
			ChatroomInfo otherMainHall = new ChatroomInfo("MainHall-" + newServer.getServerName(), "", newServer);
			Server.remoteChatrooms.put(otherMainHall.getChatRoomId(), otherMainHall);
			Server.serverList.add(newServer);
			// told all server update the information
			obj = ServerMessages.serverUpdateServerInfo(newServer);
			BroadcasterThread broadcasterThread = new BroadcasterThread(obj.toJSONString());
			broadcasterThread.start();
			
			return;
		}
		
		//process update between current server
		if(type.equals("updatebetweenserver")){
			ServerInfo newServer = null;
			boolean isContains = false;
			try {
				String servername = (String)jMessage.get("servername");
				InetAddress serverAddress = InetAddress.getByName((String)jMessage.get("address"));
				int serverPort = Integer.parseInt((String)jMessage.get("port"));
				int coordinationPort = Integer.parseInt((String)jMessage.get("managementport"));
				newServer = new ServerInfo(servername, serverAddress, serverPort, coordinationPort);
			} catch (Exception e) {
				System.out.println("New Server Info Error!");
			}
			
			for(ServerInfo s:Server.serverList){
				if(s.getServerName().equals(newServer.getServerName()))
					isContains = true;
			}
			
			if(newServer.getServerName().equals(Server.thisServerInfo.getServerName())){
				isContains = true;
			}
			
			if(!isContains){
				ChatroomInfo otherMainHall = new ChatroomInfo("MainHall-" + newServer.getServerName(), "", newServer);
				Server.remoteChatrooms.put(otherMainHall.getChatRoomId(), otherMainHall);
				Server.serverList.add(newServer);
			}
			return;
		}
	}

	public BlockingQueue<String> getMessageQueue() {
		return messageQueue;
	}

	public void write(JSONObject jMessage) {
		try {
			writer.write((jMessage.toJSONString() + "\n"));
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
