package chatSystem.models;

import java.util.ArrayList;

public class LocalChatroomInfo extends ChatroomInfo {
	private String rooomOwner;
	private static ArrayList<String> userList = new ArrayList<String>();
	
	
	public LocalChatroomInfo(String chatRoomId, String rooomOwner) {
		super(chatRoomId);
		this.rooomOwner = rooomOwner;
	}
	
	public LocalChatroomInfo() {
		
	}

	public String getRooomOwner() {
		return rooomOwner;
	}

	public void setRooomOwner(String rooomOwner) {
		this.rooomOwner = rooomOwner;
	}

	public ArrayList<String> getUserList() {
		return userList;
	}

	public void setUserList(String newUser) {
		LocalChatroomInfo.userList.add(newUser);
	}

}
