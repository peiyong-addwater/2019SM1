package chatSystem.models;

import java.util.ArrayList;

public class ChatroomInfo {
	private String chatRoomId = null;
	private String rooomOwner = "";
	private ArrayList<String> userList = new ArrayList<String>();
	private ServerInfo managingServer = null;

	public ChatroomInfo(String chatRoomId) {
		this.chatRoomId = chatRoomId;
	}
	
	public ChatroomInfo(String chatRoomId, String rooomOwner) {
		this.chatRoomId = chatRoomId;
		this.rooomOwner = rooomOwner;
	}
	
	public ChatroomInfo(String chatRoomId, ServerInfo managingServer) {
		this.chatRoomId = chatRoomId;
		this.managingServer = managingServer;
	}
	
	public ChatroomInfo(String chatRoomId, String rooomOwner, ServerInfo managingServer) {
		this.chatRoomId = chatRoomId;
		this.rooomOwner = rooomOwner;
		this.managingServer = managingServer;
	}
	
	
	public ChatroomInfo() {
		
	}

	public String getChatRoomId() {
		return chatRoomId;
	}

	public void setChatRoomId(String chatRoomId) {
		this.chatRoomId = chatRoomId;
	}
	
	public String getRooomOwner() {
		return rooomOwner;
	}

	public void setRooomOwner(String rooomOwner) {
		this.rooomOwner = rooomOwner;
	}

	public ArrayList<String> getUserList() {
		return userList;
	}

	public void setUserList(String newUser) {
		userList.add(newUser);
	}
	
	public void deleteUser(String deleteUser){
		int index = 0;
		for(int i = 0;i < userList.size();i++){
			if(userList.get(i).equals(deleteUser))
				index = i;
		}
		userList.remove(index);
	}
	
	public ServerInfo getManagingServer() {
		return managingServer;
	}

	public void setManagingServer(ServerInfo managingServer) {
		this.managingServer = managingServer;
	}
	
	@Override
	public boolean equals(Object o) {
		return this.chatRoomId.equals(((ChatroomInfo) o).chatRoomId);	
	}

}
