package chatSystem.models;

import java.net.InetAddress;

public class ServerInfo {
	private String serverName;
	private InetAddress address;
	private int port;
	private int managementPort;
	
	public ServerInfo(String serverName, InetAddress address, int port, int managementPort) {
		this.serverName = serverName;
		this.address = address;
		this.port = port;
		this.managementPort = managementPort;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public InetAddress getAddress() {
		return address;
	}

	public void setAddress(InetAddress address) {
		this.address = address;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getManagementPort() {
		return managementPort;
	}

	public void setManagementPort(int managementPort) {
		this.managementPort = managementPort;
	}

}
