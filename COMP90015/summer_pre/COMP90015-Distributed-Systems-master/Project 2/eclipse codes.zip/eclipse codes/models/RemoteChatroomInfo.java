package chatSystem.models;

public class RemoteChatroomInfo extends ChatroomInfo {
	private ServerInfo managingServer;

	public RemoteChatroomInfo(String chatRoomId, ServerInfo managingServer) {
		super(chatRoomId);
		this.managingServer = managingServer;
	}

	public ServerInfo getManagingServer() {
		return managingServer;
	}

	public void setManagingServer(ServerInfo managingServer) {
		this.managingServer = managingServer;
	}

}
