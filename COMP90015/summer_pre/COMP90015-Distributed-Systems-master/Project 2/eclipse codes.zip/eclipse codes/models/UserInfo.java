package chatSystem.models;

import javax.net.ssl.SSLSocket;

public class UserInfo {
	private String userName;
	private ChatroomInfo currentChatroom;
	private SSLSocket sslsocket;
	
	public UserInfo(String userName, ChatroomInfo currentChatroom, SSLSocket sslsocket) {
		this.userName = userName;
		this.currentChatroom = currentChatroom;
		this.sslsocket = sslsocket;
	}
	
	public UserInfo(String userName, SSLSocket sslsocket) {
		this.userName = userName;
		this.sslsocket = sslsocket;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public ChatroomInfo getCurrentChatroom() {
		return currentChatroom;
	}

	public void setCurrentChatroom(ChatroomInfo currentChatroom) {
		this.currentChatroom = currentChatroom;
	}

	public SSLSocket getSockte() {
		return sslsocket;
	}

	public void setSockte(SSLSocket sslsocket) {
		this.sslsocket = sslsocket;
	}

}
