''' Name: Hongyao Wei '''
''' ID: 741027 '''

from nltk.corpus import stopwords
from nltk.stem.porter import *
import re
import sys

''' ====== Read in a list of attributes from file ====== '''
f = open("attributes.txt", 'rU')
attributes = f.readlines()
f.close()
attributes = [re.sub(r'\n', '', attribute) for attribute in attributes]
print('read attributes file done')

''' ====== read tweets normaliser dictionary file ====== '''
f = open("tweets-dict.txt", 'rU')
lines = f.readlines()
f.close()

d = {}
for line in lines:
    words = line.split('\t')

    if d.get(words[0]):
        print('Error: OOV word should not map to multiple different entries!')
        sys.exit()
    else:
        d[words[0]] = re.sub(r'\n', '', words[1])

print('read tweets normaliser dictionary file done')


''' ====== modify attributes into better format ======'''
stop = stopwords.words('english')
# intialise the Porter Stemmer
stemmer = PorterStemmer()

mdattributes = []
for attribute in attributes:
    # normalise the words using the Unimelb ESMN
    if attribute in d:
        mdattribute = d[attribute]
    else:
        mdattribute = attribute
    
    # stem the tweet words
    mdattribute = stemmer.stem(mdattribute)
    
    # remove words that are 1 characters or less
    if len(mdattribute) == 1 or mdattribute in stop:
        mdattribute = None
    
    if mdattribute:
        mdattributes.append(mdattribute + '\n')
        
# remove duplicate attributes after normalisation
formattedAttribute = list(set(mdattributes))
print('length of attributes: ' + str(len(formattedAttribute)))
print('modify attributes done')   


''' ====== write modified tweets file ====== '''
f = open("attributes-formatted.txt", 'w')
# write the attributes to file
f.writelines(formattedAttribute)
f.close()
print('write attributes done')       