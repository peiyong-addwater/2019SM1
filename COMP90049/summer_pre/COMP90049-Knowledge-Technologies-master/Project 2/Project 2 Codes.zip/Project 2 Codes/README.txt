This program contains 3 Python files:
	tweetsNormaliser.py
	attribtueNormaliser.py
	instancesVectors.py
The Python version is:
	Python 2.7.10
The import package is:
	nltk


‘tweetsNormaliser.py’ is responsible for normalizing tweets contents by using Unimelb ESMN, stemming words, removing stop words etc. 
‘attribtueNormaliser.py’ handles attributes through similar process as ‘tweetsNormaliser.py’.
‘instancesVectors.py’ converts normalized tweets files into appropriate instance vectors according to formatted attributes (features).


Run the program:
Put all python files in the same directory, e.g. c:\program\
Put 5 datasets files (namely ‘train-tweets.txt’, ‘dev-tweets.txt’, ‘test-tweets.txt’, ‘attributes.txt’ and ‘tweets-dict.txt’) in the same directory as python files, e.g. c:\program
‘tweets-dict.txt’ is ‘English Social Media Normalisation Lexicon’ file.


In terminal:
First load to the directory (cd c:\program)
Then run programs in order by typing : 
python attribtueNormaliser.py
python tweetsNormaliser.py
python instancesVectors.py


Following output files will appear in the same directory:
attributes-formatted.txt
train-tweets-formatted.txt
dev-tweets-formatted.txt
test-tweets-formatted.txt
train-tweets-formatted-vectors.arff
dev-tweets-formatted-vectors.arff
test-tweets-formatted-vectors.arff
