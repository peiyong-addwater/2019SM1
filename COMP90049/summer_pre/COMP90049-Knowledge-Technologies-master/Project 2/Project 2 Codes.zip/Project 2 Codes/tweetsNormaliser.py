''' Name: Hongyao Wei '''
''' ID: 741027 '''

from nltk.corpus import stopwords
from nltk.stem.porter import *
import re
import sys

fileList = ["train-tweets", "dev-tweets", "test-tweets"];

''' ====== read tweets normaliser dictionary file ====== '''
f = open("tweets-dict.txt", 'rU')
lines = f.readlines()
f.close()

d = {}
for line in lines:
    words = line.split('\t')

    if d.get(words[0]):
        print('Error: OOV word should not map to multiple different entries!')
        sys.exit()
    else:
        d[words[0]] = re.sub(r'\n', '', words[1])

print('read tweets normaliser dictionary file done')


for fileName in fileList:
    ''' ====== read tweets file ====== '''
    f = open(fileName + ".txt", 'rU')
    tweets = f.readlines()
    f.close()
    print('read '+ fileName + '.txt' +' done')

    ''' ====== modify tweets contents into better format ======'''
    stop = stopwords.words('english')
    mdtweets = []
    for tweet in tweets:
        tweet_element = tweet.split('\t')
        # intialise the Porter Stemmer
        stemmer = PorterStemmer()
        
        # make all letters in the tweet text lower case
        mdtweet_text = tweet_element[2].lower()
        
        # split the tweet into words
        mdtweet_words = mdtweet_text.split(' ')
        
        # normalise the words using the Unimelb ESMN
        tweet_words = []
        for word in mdtweet_words:
            if word in d:
                tweet_words.append(d[word])
                # print(word)
                # print(d[word])
            else:
                tweet_words.append(word)
        mdtweet_words = tweet_words
        
        # remove all non-alphabetic characters (excluding space) 
        mdtweet_words = [re.sub(r'[^a-z ]', '', mword) for mword in mdtweet_words if re.sub(r'[^a-z ]', '', mword)]
        
        # stem the tweet words
        mdtweet_words = [stemmer.stem(word) for word in mdtweet_words]
        
        # remove words that are 1 characters or less
        mdtweet_words = [word for word in mdtweet_words if len(word) > 1]
        
        # remove common words
        mdtweet_words = [word for word in mdtweet_words if word not in stop]
        
        mdtweet_text = ' '.join(mdtweet_words)
        
        mdtweets.append((tweet_element[0], tweet_element[1], mdtweet_text, tweet_element[3]))

    print('modify ' + fileName + '.txt' + ' done')    
    
    ''' ====== write modified tweets file ====== '''
    f = open(fileName + '-formatted.txt', 'w')
    # convert the tweets from a 2d tupple to a tab seperated string
    tweets = ['\t'.join(tweet) for tweet in mdtweets]
    # tweets = ['\t'.join(tweet) + '\n' for tweet in mdtweets]
    # write the tweets to file
    f.writelines(tweets)
    f.close()
    print('write ' + fileName + '-formatted.txt' + ' done')  
