''' Name: Hongyao Wei '''
''' ID: 741027 '''

import re
import sys

fileList = ["train-tweets-formatted", "dev-tweets-formatted", "test-tweets-formatted"];

""" ====== Get the attributes of the feature vectors ====== """
f = open("attributes-formatted.txt", 'rU')
attributes = f.readlines()
f.close()

attributes = [re.sub(r'\n', '', attribute) for attribute in attributes] 
# ignore the first user-id attribute
attributes = [attr for attr in attributes if attr != 'id']

print('read attributes file done')

''' ====== Generate a tweet dictionary 
                key: tweet id 
                value: tweet contents ====== '''
for fileName in fileList:   
    f = open(fileName +".txt", 'rU')
    lines = f.readlines()
    f.close()
    # remove the new line character from the end of the tweet text
    lines = [re.sub(r'\n', '', line) for line in lines]
    lines = [line.split('\t') for line in lines]
    
    dTweet = {}
    dClass = {}
    for line in lines:
        if len(line) == 4:
            # first entry for this Twitter user       
            dTweet[line[1]] = line[2] 
            dClass[line[1]] = line[3]
    
    print('read '+fileName +'.txt'+' done')
    
    
    def make_vector(tweet_text, attributes):
        """ Make a feature vector corresponding to a tweet id """
        # intialise the feature vector
        vector_dict = {}
        for attribute in attributes:
            vector_dict[attribute] = 0
    
        tweet_words = tweet_text.split(' ')
        for word in tweet_words:
            if word in vector_dict:
                vector_dict[word] += 1
    
        vector_values = [str(value) for value in vector_dict.values()]
    
        return ','.join(vector_values)
    
    ''' ====== construct vector instance ====== '''
    # vector dict: key - user id integer, value - string
    vectors_dict = {}
    for entry in dTweet.items():
        if vectors_dict.get(entry[0]):
            print('Error: Twitter user ids should be unique!')
            sys.exit()
        else:
            vectors_dict[entry[0]] = make_vector(entry[1], attributes) + ',' + str(dClass[entry[0]])
            
    print('construct vector instance done')
    
    ''' ====== write vectors to file ====== '''
    # write the .arff file
    f = open(fileName +"-vectors.arff", 'w')
    # write the .arff file header 
    f.write('@RELATION twitter-loc-reduced\n')
    f.write('@ATTRIBUTE id NUMERIC\n')
    for attr in attributes:
        f.write('@ATTRIBUTE ' + attr + ' NUMERIC\n')
    f.write('@ATTRIBUTE location {B,H,SD,Se,W}\n')
    
    instance = vectors_dict.values()[0]
    print('length of attributes: ' + str(len(attributes)))
    print('length of instance vector: ' + str(len(instance.split(','))))
    
    # write the instances of vectors to file
    f.write('@DATA\n')
    for entry in vectors_dict.items():
        f.write(entry[0] + ',' + entry[1] + '\n')
        
    f.close()
    print('write file done')