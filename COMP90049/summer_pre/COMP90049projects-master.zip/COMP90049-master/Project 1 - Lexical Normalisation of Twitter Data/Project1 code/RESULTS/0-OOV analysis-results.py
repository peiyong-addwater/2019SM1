Python 3.6.2 (v3.6.2:5fd33b5926, Jul 16 2017, 20:11:06) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> 
=========== RESTART: /Users/yue/Desktop/Project 1/OOV-analysis.py ===========
right match num: 661
wrong_match num: 1220
OOV num: 1881
accurary 0.3514
error rate 0.6486
>>> 
