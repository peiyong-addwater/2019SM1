# COMP90049 Knowledge Technology Assignments: 
1. Lexical Normalisation of Twitter Data 
2. Identify Tweets with ADR

**University of Melbourne  
Semester 2 2017**
