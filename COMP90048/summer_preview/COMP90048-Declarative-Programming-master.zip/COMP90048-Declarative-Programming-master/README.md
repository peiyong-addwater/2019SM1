# COMP90048 Declarative Programming

Here are some Haskell practices from the subject Declarative Programing

Including some sample scripts in workshops, lecture quizes and assignments.
